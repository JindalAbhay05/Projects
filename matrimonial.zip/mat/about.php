<?php
include('connection.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Marital Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!--font-Awesome-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--font-Awesome-->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<script>
var isNS = (navigator.appName == "Netscape") ? 1 : 0;

if(navigator.appName == "Netscape") document.captureEvents(Event.MOUSEDOWN||Event.MOUSEUP);

function mischandler(){
return false;
}

function mousehandler(e){
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if((eventbutton==2)||(eventbutton==3)) return false;
}
document.oncontextmenu = mischandler;
document.onmousedown = mousehandler;
document.onmouseup = mousehandler;

</script>
</head>
<body>
	<div>
<?php
	include('menu.php');
?>
</div>
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">About</li>
     </ul>
   </div>
   <div class="about">
   	  <div class="col-md-6 about_left">
   	  	<?php
		$gft="select pic from about_us_qualities";
		$rt=mysqli_query($con,$gft);
		while($op=mysqli_fetch_array($rt))
		{
		?>
   	  	<img src="admin/up1/<?php echo $op['pic'];?>" class="img-responsive" alt=""/>
   	  	<?php
   	 	 }
   	  	?>
   	  </div>
   	  <div class="col-md-6 about_right">
   	  	<h1>About us</h1>
   	  	<?php
   	  	$gft2="select descrip from about_us_qualities";
		$rt250=mysqli_query($con,$gft2);
		while($op250=mysqli_fetch_array($rt250))
		{
		?>
   	  	<p><?php echo $op250['descrip'];?></p>
   	  	<?php
   	  	}

   	  	$gft22="select quality1,desc1 from about_us_qualities LIMIT 1";
		$rt260=mysqli_query($con,$gft22);
		while($op270=mysqli_fetch_array($rt260))
		{
   	  	?>
   	  	<div class="accordation">
		   <div class="jb-accordion-wrapper">
				<div class="jb-accordion-title"><?php echo $op270['quality1'];?> <button type="button" class="jb-accordion-button" data-toggle="collapse" data-target="#accordion-1-"><i class="fa fa-angle-down"> </i></button></div>
				<p><!-- /.accordion-title -->
				</p><div id="accordion-1-" class="jb-accordion-content collapse in" style="height: auto;">
				<p><?php echo $op270['desc1'];?></p>
				</div>
				<p><!-- /.collapse --></p>
			</div>
			<?php
			}

			$cmd22="select quality2,desc2 from about_us_qualities LIMIT 3";
			$rt265=mysqli_query($con,$cmd22);
			while($op3=mysqli_fetch_array($rt265))
			{
			?>
			<div class="jb-accordion-wrapper">
				<div class="jb-accordion-title"><?php echo $op3['quality2'];?> <button type="button" class="jb-accordion-button" data-toggle="collapse" data-target="#accordion2-"><i class="fa fa-angle-down"> </i></button></div>
				<p><!-- /.accordion-title--> 
				</p><div id="accordion2-" class="jb-accordion-content collapse ">
				<p><?php echo $op3['desc2'];?></p>
				</div>
				<p><!-- /.collapse--> </p>
			</div>
			<?php
			}
			$cmd23="select quality3,desc3 from about_us_qualities LIMIT 3";
			$rt29=mysqli_query($con,$cmd23);
			while($op39=mysqli_fetch_array($rt29))
			{
			?>
			<div class="jb-accordion-wrapper">
				<div class="jb-accordion-title"><?php echo $op39['quality3'];?><button type="button" class="jb-accordion-button" data-toggle="collapse" data-target="#accordion3"><i class="fa fa-angle-down"> </i></button></div>
				<p><!-- /.accordion-title -->
				</p><div id="accordion3" class="jb-accordion-content collapse ">
				<p><?php echo $op39['desc3'];?> </p>
				</div>
				<p><!-- /.collapse --></p>
			</div>
			<?php
			}
			?>
		</div>
   	  </div>
   	  <div class="clearfix"> </div>
   </div>
  </div>
</div>
<div class="about_middle">
	<div class="container">
	  <h2>Happy Clients</h2>
	  <div class="about_middle-grid1">
	  	<?php
	  	$qry="select * from about_us ORDER BY RAND() LIMIT 1";
	  	$r=mysqli_query($con,$qry);
	  	while($o=mysqli_fetch_array($r))
	  	{
	  	?>
		<div class="col-sm-6 testi_grid list-item-0">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="admin/up1/<?php echo $o['client_pic'];?>" class="img-responsive" alt=""/>
				</figure>
				<div><a href="#"><?php echo $o['client_desc'];?></a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
		    <small class="testi-meta"><span class="user"><?php echo $o['client_name'];?></span></small>
		</div>
		<?php
		}

	  	$kry="select * from about_us ORDER BY RAND() LIMIT 1";
	  	$r1=mysqli_query($con,$kry);
	  	while($o1=mysqli_fetch_array($r1))
	  	{
	  	?>
		<div class="col-sm-6 testi_grid list-item-1">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="admin/up1/<?php echo $o1['client_pic'];?>" class="img-responsive" alt=""/>
				</figure>
				<div><a href="#"><?php echo $o1['client_desc'];?></a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
			<small class="testi-meta1"><span class="user"><?php echo $o1['client_name'];?></span></small>
		</div>
		<?php
		}
		?>
		<div class="clearfix"> </div>
	  </div>
	  <div class="about_middle-grid2">
	  	<?php
	  	$qry4="select * from about_us ORDER BY RAND() LIMIT 1";
	  	$r45=mysqli_query($con,$qry4);
	  	while($o3g=mysqli_fetch_array($r45))
	  	{
	  	?>

		<div class="col-sm-6 testi_grid list-item-0">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="admin/up1/<?php echo $o3g['client_pic'];?>" class="img-responsive" alt=""/>
				</figure>
				<div><a href="#"><?php echo $o3g['client_desc'];?></a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
		    <small class="testi-meta"><span class="user"><?php echo $o3g['client_name'];?></span></small>
		</div>
		<?php
		}

	  	$kry258="select * from about_us ORDER BY RAND() LIMIT 1";
	  	$r6=mysqli_query($con,$kry258);
	  	while($o5=mysqli_fetch_array($r6))
	  	{
	  	?>
		<div class="col-sm-6 testi_grid list-item-1">
			<blockquote class="testi_grid_blockquote">
				<figure class="featured-thumbnail">
					<img src="admin/up1/<?php echo $o5['client_pic'];?>" class="img-responsive" alt=""/>
				</figure>
				<div><a href="#"><?php echo $o5['client_desc'];?></a>
				<div class="clearfix"></div>
				</div>
			</blockquote>
			<small class="testi-meta1"><span class="user"><?php echo $o5['client_name'];?></span></small>
		</div>
		<?php
		}
		?>
		<div class="clearfix"> </div>
	  </div>
	</div>
</div>
<div class="about_bottom">
	<div class="container">
		<h3>Team</h3>
		<?php
		$r2ty="select * from about_us_team";
		$yu=mysqli_query($con,$r2ty);
		while($rew=mysqli_fetch_array($yu))
		{
		?>
	   <div class="col-md-3 about_grid1">
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="admin/up1/<?php echo $rew['pic'];?>"  class="img-responsive" alt=""/></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			    <div class="desc">
			    	<h4><a href="#"><?php echo $rew['name'];?></a></h4>
			    	<p><?php echo $rew['descrip'];?></p>
			    </div>
			 </li>
	       </ul>
	   </div>
	   <?php
		}
	   ?>
	   <!--<div class="col-md-3 about_grid1">
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="images/a5.jpg"  class="img-responsive" alt=""/></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			    <div class="desc">
			    	<h4><a href="#">Aspernatur </a></h4>
			    	<p>Lorem ipsum dolor sit amet,</p>
			    </div>
			 </li>
	       </ul>
	   </div>
	   <div class="col-md-3 about_grid1">
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="images/a6.jpg"  class="img-responsive" alt=""/></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			    <div class="desc">
			    	<h4><a href="#">Temporibus</a></h4>
			    	<p>Lorem ipsum dolor sit amet,</p>
			    </div>
			 </li>
	       </ul>
	   </div>
	   <div class="col-md-3 about_grid1">
		  <ul class="posts-grid our-team">
			<li class="list-item-1">
				<figure class="thumbnail_1 thumbnail">
					<a href="#"><img src="images/a7.jpg"  class="img-responsive" alt=""/></a>
					<div class="post_networks">
						<ul>
							<li class="network_0"><a href="#" title=""><i class="fa fa-facebook"></i></a></li>
						</ul>
					</div>
			    </figure>
			    <div class="desc">
			    	<h4><a href="#">Serferendis</a></h4>
			    	<p>Lorem ipsum dolor sit amet,</p>
			    </div>
			 </li>
	       </ul>
	   </div>-->
	   <div class="clearfix"> </div>
	</div>
</div>
<?php
  include('footer.php');
  ?>
</body>
</html>	