
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<script src="css/jquery.min.js"></script>
	</head>
	<div class="main">
	<body class="signup">
		<div>
			<?php
				include('menu2.php');
			?>
		</div>
				<div style="margin-top:50px;background-color:#fff;"class="col-md-offset-4 col-md-4">
			<p class="log text-center" style="color:#6495ED;" s>Join Youngsters<br>
				<span style="font-family:ariali;font-size:16px;color:#000;">...now please enter the following requesites,to shop on the website.</span><p>
				<div>
					<form action="signupdatabase.php" method="post">
				<i class="fa fa-user pfa" style="color:#000;" ></i>
				<input type="text" name="unameplz" placeholder="Enter Name" style="color:#000;" class="in2"><br/>
				<i class="fa fa-user ufa" style="color:#000;" ></i>
				<input type="text" name="uname" placeholder="Username" style="color:#000;" pattern="[a-z, ,1-10,A-Z,@,.]{1,15}" title="it should be in lowercase,space,uppercase,one numeric digit" class="in1"><br/>
				<i class="fa fa-key pfa" style="color:#000;" ></i>
				<input type="password" name="upass" placeholder="Password" style="color:#000;" pattern=".{6,10}" class="in2"><br/>
				<i class="fa fa-phone pfa" style="color:#000;" ></i>
				<input type="text" name="uphn" placeholder="Phone Number" style="color:#000;" class="in2"><br/>
				<i class="fa fa-location-arrow pfa" style="color:#000;" aria-hidden="true"></i>
				<textarea type="text" name="uadd" placeholder="Enter Address" style="color:#000;" pattern=".{50,100}" class="in2"></textarea><br>
				
				<input type="submit" name="signup" value="Sign up" class="btn btn-md btn-lg btn-block" 
				style="margin-top:25px;background-color:#005580;color:#fff;">
			</form>
				</div>				
		</div>
	</div>
	</body>
</html>