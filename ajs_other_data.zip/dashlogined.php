<?php
session_start();
if(!isset($_SESSION['uid']))
{
	header("location:dashboard.php");
}
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<div class="main">
			
			<div class="col-md-3 col-md-offset-5">
				<a href="index.php" style="font-size:25px;font-family:'BELLI';color:#0077b3;font-weight:bolder;">Youngsters.com<br>
                           <span style="font-family:'BELLI';color:#0077b3;"class="te"> &nbsp;&nbsp;
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from A.J.</span></a>
			</div>
			<div class="clearfix"></div>
		<div style="margin-top:10px;">
			<img src="images/fronfacecpy.jpg">
		</div>
		<div class="clearfix"></div>
		<div style="margin-top:50px;"class="container">
			<div cLass="col-md-2 col-md-offset-1">
				<center><a href="dashsigning.php" ><i class="fa fa-users text-center"style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Signing</span><br>
					All the login or <br>signup users data

				</a></center>
				<!--signning-->
			</div>
			<div cLass="col-md-2">
				<center><a href="dashcateg.php" class="text-center"><i class="fa fa-spinner" style="font-size:30px;"></i><br>
					<span style="color:black;font-weight:bolder;">Categories</span><br>
					All the Men,Women, <br> Watches,Footwear<br> Products addition.

				</a></center>
				<!--catgories-->
			</div>
			<div cLass="col-md-2">
				<center><a href="dashslider.php" class="text-center"><i class="fa fa-picture-o" aria-hidden="true" style="font-size:30px;"></i>
<br>
					<span style="color:black;font-weight:bolder;">Slider Photos</span><br>
					Add the slider <br>photos.

				</a></center>
				<!--photos-->
			</div>
			<div cLass="col-md-2">
				<center><a href="dashuserup.php" class="text-center"><i class="fa fa-user" aria-hidden="true" style="font-size:30px;"></i>
<br>
					<span style="color:black;font-weight:bolder;">Sign up</span><br>
					Add a person <br>in admin.

				</a></center>
				<!--photos-->
			</div>
			<div cLass="col-md-2">
				<center><a href="byed.php" ><i class="fa fa-archive text-center"style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Products Buyed</span><br>
					All the details of<br>products buyed.

				</a></center>
				<!--signning-->
			</div>
		</div>
		</div>
	</body>
</html>