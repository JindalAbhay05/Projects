<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();

if(!isset($_SESSION['name']))
{
	//header('login.php');
	echo "<script> window.location='login.php'; </script>";
}
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>

  <!--addclassjqueery--><script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<link href="css/style.css" rel="stylesheet">
</head>
<body>
	<div>
		<?php
		 include('menu2.php');
		?>
	</div>
	<?php
	if(isset($_POST['nji']))
	{
	?>
	<center><p style="font-size:20px;font-weight:bold;"> THANK YOU</p>
	<p> Your product will be delivered at your door.<br>Pay Cash when the product is delivered.</p></center>
	<?php
	
		
	$_POST['seld'];
		//echo $_POST['seld'];
	$_SESSION['prod_id']=$_GET['prod_id'];
	//echo $_SESSION['prod_id'];
	$qry="select name,address,phone_numbr from user_login where username='".@$_SESSION['name']."'";
	$ytu=mysqli_query($con,$qry);
	while($ruu=mysqli_fetch_array($ytu))
	{
		$nal=$ruu[0];
		$dfs=$ruu[1];
		$asd=$ruu[2];
	}
	$cmd="select id,name,price,size,photo,description,subcat_id,sprcat_id,newcat_id from products where id=".$_SESSION['prod_id'];

	$res=mysqli_query($con,$cmd);
	while($row1=mysqli_fetch_array($res))
	{
		$subid=$row1[6];
		$mainid=$row1[8];
		$sprid=$row1[7];
		//echo $row1[1];
		?>
		<div class="col-md-8 col-md-offset-2" style="margin-top:50px;">
			<div class="col-md-3">
				<p class="po text-center">Cash On Delivery</p>
			</div>
			<div class="col-md-9">
				<div class="col-md-9">
				<p><p><label>NAME:</label><?php echo $nal;?></p></p>
				<p><label>ADDRESS:</label><?php echo $dfs;?></p>
				<p><label>PHONE NUMBER:</label><?php echo $asd;?></p>
				<p><label>PROD. ID:</label> <?php echo $row1[0];?></p>
				<p><label>PROD. NAME:</label> <?php echo $row1[1];?></p>
				<p><label>PROD. DESCRIPTION:</label> <?php echo $row1[5];?></p>
				<p><label>PROD. PRICE:</label>Rs: <?php echo $row1[2];?></p>				
				<p><label>PROD. SIZE:</label> <?php echo $row1[3];?></p>


			</div>
			<div class="col-md-3">
				<img src="images/products/<?php echo $row1[4];?>" width="200"></img>
			</div>
			</div>
	</div>
	<?php
	$rty="insert into record(prod_id,newcat_id,subcat_id,sprcat_id,name,price,phoneno,prod_name,address) value('$row1[0]','$mainid','$subid','$sprid','$nal','$row1[2]','$asd','$row1[1]','$dfs')";
	mysqli_query($con,$rty);
	
	}
}
else{
	//header('login.php');
}
?>

</body>
</html>
