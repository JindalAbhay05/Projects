<!--$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});-->

<?php
	$cn=mysqli_connect("localhost","root","","youngsters");
	//mysqli_select_db("youngsters",$cn);
	session_start();



	
	
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<!--tooltip file--><script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<script>
	$(document).ready(function(){

		$('#default').load("fil1.php?subid=<?php echo @$_GET['subid'];?>&mainid=<?php echo @$_GET['mainid'];?>&sprid=<?php echo @$_GET['sprid'];?>&brid=<?php echo @$_GET['brid'];?>");
		
		$("#siz").hide();
		$("#as").hide();
		$("#minus").click(function(){
			$("#aa").toggle();
			});
		$("#min1").click(function(){
			$("#ab").toggle();
		});
		
		$("#nam").mouseover(function(){
			$("#r").hide();
			$("#as").show();
			$("#siz").show();
			
		});

		$("#nam").mouseleave(function(){
			$("#r").show();
			$("#as").hide();
			$("#siz").hide();
					});
		
			$("input:radio[name='br']").click(function(){

				var brid=$("input:radio[name='br']:checked").val();
				$('#default').load("fil2.php?brid="+brid+"&mainid=<?php echo $_GET['mainid'];?>");

			});

	});
	</script>
	</head>
	<body>
		
		<div class="main">
			<div>
				<?php
				include('menu2.php');
				?>
			</div>
			<div class="col-md-2" style="padding-left:7px;padding-right:0px;">
					<div><!--brands-->
						<p style="color:#000;font-weight:bolder;font-family:'BELLI';">BRAND
							<i id="minus" class="fa fa-minus-circle filter abc" style="margin-left:125px;color:#6495ED;"></i></p>
							<div class="clearfix"></div>
						<div id="aa" >

							<?php
							$cmd="select id,name from companies where maincat_id='".$_GET['mainid']."'";
							$res=mysqli_query($cn,$cmd);
							while($row=mysqli_fetch_array($res))
							{
							?>
						<input type="radio" name="br" value="<?php echo $row[0];?>"><span style="font-weight:bold;"><?php echo $row[1];?></span><br>

						<?php
							}
						?>
					</div>
					</div>
					<hr>
					<!--<div>
						<p style="color:#000;font-weight:bolder;font-family:'BELLI';">COLOUR
							<i id="min1" class="fa fa-minus-circle filter abc" style="margin-left:120px;color:#6495ED;"></i></p>
							<div id="ab">
				<span data-toggle="tooltip" title="black" name="black" class="cr" style="display:inline-block;width:29px;height:20px;background-color:#000;" ></span>
				<span data-toggle="tooltip" title="green" name="green" class="cr" style="display:inline-block;width:29px;height:20px;background-color:green;"></span>
				<span data-toggle="tooltip" title="blue" name="blue" class="cr" style="display:inline-block;width:29px;height:20px;background-color:blue;"></span>
							</div>
					</div>-->
					<hr>
					<div class="clearfix"></div>

				</div>
				<div class="col-md-10" id="default">
				</div>
				
							
		</div>
	</body>
	</html>