<?php
$cn=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$cn);


?>

<script>

    $(document).ready(function(){
      $("#a").hide();

            $("#discover").click(function(){
        $("#a").slideDown();
          $("$discover").hide();
      });

      $("#b").click(function(){
        $("#a").hide();
      });
    });

</script>
 	    <div>
<!--to be hidden starts--><div id="a"  style="position:fixed;z-index:10000;background-color:#dcdcdc;width:100%; "><!--to be hidden starts-->
<div style="font-size:15px;" class="col-md-1 col-md-offset-11"><span class="fa fa-times" id="b" style="font-weight:bolder;"> &nbsp;&nbsp;&nbsp;CLOSE</span>
                            </div>
                <div class="col-md-offset-5">
                    <span class="text1" style="font-size:25px;font-family:'BELLI';color:#0b0b0b;margin-top:-100px;">Youngsters.com</span><br>
                    <span class="text1 text2" style="color:#0b0b0b;">&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from A.J.</span>
            
                </div>
					
					<div style="margin-top:150px;" class="col-md-6 col-md-offset-4">
<p style="color:#0b0b0b;font-weight:bolder;font-size:25px;margin-left:80px;">&nbsp;&nbsp;&nbsp;&nbsp;Discover Products And Collection<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Write any two letters</p>
<script>
 function showResult(str) {
  if (str.length==0) {
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    document.getElementById("livesearch").style.borderRadius="15px";
    document.getElementById("livesearch").style.background="none";
    return;
  }
 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

      xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200) {
            document.getElementById("livesearch").innerHTML=xmlhttp.responseText;
            document.getElementById("livesearch").style.border="1px solid #ccc";
        document.getElementById("livesearch").style.borderRadius="15px";
            //document.getElementById("livesearch").style.width="400px";
            document.getElementById("livesearch").style.background="rgb(255,255,255)";
             //document.getElementById("livesearch").style.margin="0px auto";
             document.getElementById("livesearch").style.padding="5px";
                document.getElementById("livesearch").style.height="300px";
                   document.getElementById("livesearch").style.overflow="auto";

          }
        }

  xmlhttp.open("GET","livesearch.php?q="+str,true);
  xmlhttp.send();

}
</script>
<input type="text" class="hid" onkeyup="showResult(this.value)" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Start typing to discover...">
 <div id="livesearch" ></div>
 
														</div>
			</div><!--to be hidden ends-->
   	    <div class="mmain"><!--main the topost div-->
            <div class="col-md-5">
                    <span id="discover" class="textt col-md-4" style="margin-top:5px;background-color:#0077b3;"><i class="fa fa-search"></i> Discover Deals</span>
            </div>
            <div class="col-md-3 col-md-offset-5 yi">
                       
            <a href="index.php" class="w text1" style="font-size:25px;font-family:'BELLI';background-color:#0077b3;font-weight:bolder;">Youngsters.com<br>
                           <span style="font-family:'BELLI';" class="te"> &nbsp;&nbsp;
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from A.J.</span></a>
               </div>
        </div>
                <!-- collapsable menu -->
<nav class="navbar" >
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <i class="fa fa-bars fa-lg" style="color:#fff;"></i>                      
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="s"><a class="s1 s2 abc" href="index.php">Home</a></li>
        <?php
            $cmd="select id,name,photo2 from new_category";
            $res=mysqli_query($cn,$cmd);
            while($row=mysqli_fetch_array($res))
            {
                $id=$row[0];
                
            ?>
        <li class="dropdown s">
            
          <a class="dropdown-toggle s1 s2" data-toggle="dropdown" href="#"><?php echo $row[1];?></a>
          
          <ul class="dropdown-menu multi-column columns-2">
         
          
            <div class="row">
                <div class="col-md-6">
                  <ul class="multi-column-dropdown">
                    <?php
          $cmd2="select id,subcatname from add_subcat where pcatid='$id'";
          $res2=mysqli_query($cn,$cmd2);
          while($row2=mysqli_fetch_array($res2))
          {
            $id1=$row2[0];
           
          ?>
                    
                         
            <li class="list1 g"><a href="designing.php?subid=<?php echo $row2[0];?>&mainid=<?php echo $id?>" class="e" style="font-weight:bolder;color:orange;"><?php echo $row2[1];?></a>
                <ul>
                   <?php
                   
                      $cmd3="select id,suprcatname from super_subcat where subcatid='$id1'";
                      $res3=mysqli_query($cn,$cmd3);
                      while($row3=mysqli_fetch_array($res3))
                      {
                      ?>
                    <li class="g">
                     <a href="designing.php?sprid=<?php echo $row3[0];?>&mainid=<?php echo $id?>" style="color:#000;"><?php echo $row3[1];?></a>
                    </li>
                   <?php
                    }
                  
                    ?>
                </ul>
                <?php
              }
                ?>
            </li>
            </ul>
            
                </div>
               
                 
                <div class="col-md-6">
                    
                    <ul class="multi-column-dropdown">
                    
                        <img src="images/<?php echo $row[2];?>" width="200px" style="">
                        
                    </ul>

                </div>
            </div>
              
             
             </ul>
        </li>
        <?php
         }
             ?>
     </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php

       
if(isset($_SESSION['name']))
{
  $cmd100="select name from user_login where username='".@$_SESSION['name']."'";
        $res100=mysqli_query($cn,$cmd100);
        while($jf=mysqli_fetch_array($res100))
        {
          @$_SESSION['hkjk']=$jf[0];
          
        }
        
        ?>
        <li class="s"><a id="lj" class="s1 abc"><i class="fa fa-sign-in"></i><?php echo @$_SESSION['hkjk'];?></a></li>
        <li class="s"><a id="logout" href="logout.php" class="s1"><i class="fa fa-sign-in"></i> Logout</a></li>
        <?php
}
else{
?>
<li class="s"><a id="join" href="signup.php" class="s1" style="text-decoration:none;"><i class="fa fa-user"></i> Join</a></li>
        <li class="s"><a id="lgin" href="login.php" class="s1"><i class="fa fa-sign-in"></i> Login</a></li>       
<?php
}

?>
      	
        
        
        
        
      </ul>
    </div>

  </div>
</nav>
				</div>
            
 		</div>
