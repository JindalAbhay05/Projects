<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();

if(!isset($_SESSION['name']))
{
	
	header("location:dashboard.php");
}
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<div class="main">
			<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div>
			<img src="images/11466607424678-Denim-fest-feed.jpg">
		</div>

		<div class="col-md-3">
			
			<div>
			<center><a><i class="fa fa-plus" style="font-size:30px;">C</i>
					<br><span style="color:black;font-weight:bolder;">Add Category</span></a></center>
			</div>	
			<div class="clearfix"></div>
			<!--input box--><div style="margin-top:20px;">
			<form action="dashcateg.php" method="post" enctype="multipart/form-data">
			<input type="text" required name="name"placeholder="Write Category Name" style="border-top:0px;border-left:0px;border-right:0px;width:100%;border-bottom:2px solid red;font-size:20px;"><br>

			<br>
			<input type="file" name="upld"/>
			<p style="font-size:16px;margin-top:10px;margin-bottom:0px;">Inner Photo of main cat:</p>
			<input type="file" name="upld1"/>
			<p style="font-size:16px;margin-top:10px;margin-bottom:0px;">Inner Menu Photo of main cat:</p>
			<input type="file" name="upld2"/>
			<input type="submit" name="sub" value="Submit" style="margin-top:15px;" class="btn btn-md btn-primary s"/>
		</form>
		<?php
			if(isset($_POST['sub']))
			{
						
				$name=$_POST['name'];
				$photo=basename($_FILES['upld']['name']);
				$photo1=basename($_FILES['upld1']['name']);
				$photo2=basename($_FILES['upld2']['name']);
				$cmd="insert into new_category(name,photo,photo1,photo2) values('$name','$photo','$photo1','$photo2')";
				mysqli_query($con,$cmd);
				
				move_uploaded_file($_FILES['upld']['tmp_name'],"images/".$photo);
				move_uploaded_file($_FILES['upld1']['tmp_name'],"images/".$photo1);
				move_uploaded_file($_FILES['upld2']['tmp_name'],"images/".$photo2);
			}
		?>
			</div><!--end input box-->

		</div>

		<div class="col-md-9">
		<div  class="col-md-offset-1">
		<p style="font-size:30px;text-decoration:underline;">Categories:-</p>
	</div>
		
		<div style="margin-top:70px;">
			<?php
				$qry="select id,name,photo from new_category";
				$res=mysqli_query($con,$qry);
				while($row=mysqli_fetch_array($res))
				{
				?>
			<div class="col-md-3">
				
		<center><a href="commondash.php?id=<?php echo $row[0];?>" ><img width="142px" height="183px" src="images/<?php echo $row[2];?>"></i>
					<br><span style="color:black;font-weight:bolder;"><?php echo $row[1];?></span>
					

				</a></center>
			</div>
			<?php
		}
			?>
	</div>
	</div>
		</div>
	</body>
</html>
