<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<script>
	$(document).ready(function(){
		$("#b").hide();
		$("#add").click(function(){
			$("#b").toggle();
		});
	});
	</script>
	</head>
	<body>
		<div class="main">
			<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div class="container" style="margin-top:20px;">
		
			<div class="col-md-3 col-md-offset-4" style="margin-top:20px;"><!--2nd row-->
				
				<center><a id="add"><i class="fa fa-plus" style="font-size:30px;">C</i>
					<br><span style="color:black;font-weight:bolder;">Add Category</span>
					

				</a></center>
				
			</div>
		</div>
		<hr>
		<hr>
		<div class="col-md-3">
			<form action="#" method="get">
			<input type="text" placeholder="Write Category Name" style="border-top:0px;border-left:0px;border-right:0px;width:40%;border-bottom:2px solid red;font-size:20px;"><br>
			<br>
			<input type="submit" value="submit">
		</form>
		</div>
		</div>
	</body>
</html>
