<?php
	
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);


	$slider_id=$_GET['slider_id'];
	
	$tyr="delete from slider_photos where id='$slider_id'";
		mysqli_query($con,$tyr);
		header("location:dashslider.php");
?>