<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<div class="main">
		<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div style="margin-top:50px;"class="col-md-offset-4 col-md-4">
			<p class="log text-center">Youngsters<p>
				<form action="adlogincheck.php" method="post">
				<i class="fa fa-user ufa"></i><input type="text" name="lvname" placeholder="Username" class="in1"><br/>
				<i class="fa fa-key pfa"></i><input type="password" name="lvpass" placeholder="Password" class="in2"><br/>
				<input type="submit" value="Log in" name="justlvme" class="btn btn-md btn-lg btn-block" style="margin-top:25px;background-color:#005580;color:#fff;">
				
			</form>
			<div> 
					<?php 
					if(@$_GET['id']==2000)
					{
						?>
						<p style="margin-left:120px;color:red;margin-top:-10px;"><?php echo @"Wrong username/password.";?></p>
						<?php
					}
				?></div>
		</div>
	</div>
	</body>
</html>