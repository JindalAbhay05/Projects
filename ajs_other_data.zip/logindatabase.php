<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
					if(isset($_POST['login']))
					{
						
						$uname=$_POST['uname'];
						$upassword=$_POST['upassword'];
						$qry="select id,username from user_login where username='$uname' AND password='$upassword'";
						$data=mysqli_query($con,$qry);
						$counter=mysqli_num_rows($data);
						
						if($counter>0)
								{
									$row=mysqli_fetch_array($data);
									$_SESSION['uid']=$row[0];
									
									$_SESSION['name']=$row[1];
									
									header("location:index.php");
								}
						else
						{
							header("location:login.php?id=1000");
						}

					}
				?>