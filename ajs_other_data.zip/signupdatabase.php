<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);

if(isset($_POST['signup']))
{
$khjh=$_POST['unameplz'];
$uname=$_POST['uname'];
$upass=$_POST['upass'];
$phn=$_POST['uphn'];
$add=$_POST['uadd'];
$cmd="insert into user_registration(uname,phone_numbr,upass,address,name) value('$uname','$phn','$upass','$add','$khjh')";
mysqli_query($con,$cmd);


$cmd1="insert into user_login(username,password,address,name,phone_numbr) values('$uname','$upass','$add','$khjh','$phn')";
mysqli_query($con,$cmd1);
header("location:index.php");

}


?>