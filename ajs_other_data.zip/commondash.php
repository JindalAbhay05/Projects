<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
if(isset($_GET['id']))
{

	$_SESSION['maincatid']=$_GET['id'];

}

?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<script>
	$(document).ready(function(){
		$("#scatadd").hide();
		$("#superid").hide();
		$("#y").hide();
		$("#srec").hide();
		$("#ssub1").hide();
		$("#comp1").hide();

		$("#addcat").click(function(){
			$("#scatadd").slideToggle();
		});
		$("#adsupcat").click(function(){
			$("#superid").slideToggle();
		});
		$("#add").click(function(){
			$("#y").slideToggle();
		});

		$("#adcomp").click(function(){
			$("#comp1").slideToggle();
		});

		$("#rec").click(function(){
			$("#srec").slideToggle();
		});

		$("#sub").click(function(){
			$("#ssub1").slideToggle();
		});
	});
	</script>
	
	</head>
	<body>
		<div class="main">
			<!--<?php
			//$cmd="select id from add_subcat where pcatid=$_SESSION[maincatid]";
		//$fc=mysqli_query($cmd);
		//while($subid=mysqli_fetch_array($fc))
		{
			//$_SESSION['subid']=$subid[0];
			?>
			//<p><?php //echo $_SESSION['subid']."<br>";?></p>
			<?php
			}
			//$cmd1="select id from super_subcat where pcatid=$_SESSION[maincatid]";
		//$fc1=mysqli_query($cmd1);
		//while($sprid=mysqli_fetch_array($fc1))
		{
			//$_SESSION['sprid']=$sprid[0];
			?>
			<p>super<?php// echo $_SESSION['sprid']."<br>";?></p>
			<?php
			}
		?>-->
			<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div style="margin-top:15px;">
			<div class="col-md-2">
				<center><a class="abc" id="add"><i class="fa fa-plus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Add product.</span>
					

				</a></center>
			</div>
			<div class="col-md-2">
				<center><a class="abc" id="sub"><i class="fa fa-minus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Delete Product</span>
					

				</a></center>
			</div>
			<div class="col-md-2">
				<center><a class="abc" id="rec" ><i class="fa fa-archive" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Watch for Record.</span>
					

				</a></center>
			</div>
			<div class="col-md-2">
				<center><a class="abc" id="addcat"><i class="fa fa-plus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Add Sub-Category </span>
					

				</a></center>
			</div>
			<div class="col-md-2">
				<center><a class="abc" id="adsupcat"><i class="fa fa-plus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Add Super-Sub-Category </span>
					

				</a></center>
			</div>
			<div class="col-md-2">
				<center><a class="abc" id="adcomp"><i class="fa fa-plus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Add Companies </span>
					

				</a></center>
			</div>
		</div>
		<div class="clearfix"></div>
		<hr>
		<hr>
		<div id="ssub1">
			<?php
			$tasfjk="select id,name,price,photo from products where newcat_id='".$_SESSION['maincatid']."'"; 
			$usdj=mysqli_query($con,$tasfjk);?>
			<table class="table" border='1'>
			<tr class="thead">
			<th>Product ID</th>
			<th>Product Name</th>
			<th>Price</th>
			<th>Photo</th>
			<th>Delete</th>
			</tr>
			<?php
			while($osnj=mysqli_fetch_array($usdj))
			{
				?>
			<tr>
			<td><?php echo $osnj[0]; ?></td>
			<td><?php echo $osnj[1]; ?></td>
			<td><?php echo $osnj[2]; ?></td>
			<td><img src="images/products/<?php echo $osnj[3];?>" width="100px"></td>
			<td><a class="btn abc tgd" href="delproduct.php?prod_id=<?php echo $osnj[0];?> & mainid=<?php echo $_SESSION['maincatid']?>" style="background-color:#000;color:#fff;padding:10px 10px;margin-top:10px;">Delete</a></td>
			</tr>
			<?php
			}
			?>
			</table>
		</div>
		<div id="srec">
			<?php
			$t="select id,name,price,color,brand,description,photo from products where newcat_id='".$_SESSION['maincatid']."'"; 
			$u=mysqli_query($con,$t);?>
			<table class="table" border='1'>
			<tr class="thead">
			<th>Product ID</th>
			<th>Product Name</th>
			<th>Price</th>
			<th>Color</th>
			<th>Brand</th>
			<th>Description</th>
			<th>Photo</th>

						</tr>
			<?php
			while($o=mysqli_fetch_array($u))
			{
				?>
			<tr>
			<td><?php echo $o[0]; ?></td>
			<td><?php echo $o[1]; ?></td>
			<td><?php echo $o[2]; ?></td>
			<td><?php echo $o[3] ?></td>
			<td><?php echo $o[4] ?></td>
			<td><?php echo $o[5] ?></td>
			<td><img src="images/products/<?php echo $o[6];?>" width="100px"></td>
			</tr>
			<?php
			}
			?>
			</table>
		</div>
		<div id="scatadd">
			<div class="col-md-4 col-md-offset-4">
			<form action="commondash.php?id=<?php echo $_SESSION['maincatid'];?>" method="get">
			
				<input type="text" required name="name" placeholder="Write Sub Category Name" style="border-top:0px;border-left:0px;border-right:0px;width:100%;border-bottom:2px solid red;font-size:20px;"><br><br>
				<input type="submit" value="submit" name="sub1">
			</form>
			<?php

			if(isset($_GET['sub1']))
			{
				$name=$_GET['name'];
				$pcatid=$_SESSION['maincatid'];
				$qry="insert into add_subcat(pcatid,subcatname)value('$pcatid','$name')";
				mysqli_query($qry); 
			}
			?>
			</div>
		</div>
		<div id="superid">
			<form action="commondash.php?id=<?php echo $_SESSION['maincatid'];?>" method="get">
			<div class="col-md-3">
					<?php
					
					$maincatid=$_SESSION['maincatid'];
				
					
					$pgid=$_SESSION['maincatid'];
					$cmd="select id,subcatname from add_subcat where pcatid='".$pgid."'";
					$data=mysqli_query($con,$cmd);
					while($row=mysqli_fetch_array($data) )
					{
						$subctid=$row[0];
						?>
							<input type="radio" value="<?php echo $row[0];?>">
						<span style="font-weight:bolder;"><?php echo $row[1]?></span><br>
						<?php
					}
					?>		
			</div>
		<div class="col-md-4">
			
			
			<input type="text" required name="name1" placeholder="Write Super Sub Category Name" style="border-top:0px;border-left:0px;border-right:0px;width:100%;border-bottom:2px solid red;font-size:20px;"><br><br>
				<input type="submit" value="submit" name="sub2">
			</form>
			<?php

			if(isset($_GET['sub2']))
			{
				$name=$_GET['name1'];
				$pcatid=$_SESSION['maincatid'];
				$subcat=$subctid;
				
				$qry1="insert into super_subcat(pcatid,subcatid,suprcatname) value('$pcatid','$subcat','$name')";
				mysqli_query($con,$qry1); 
			}
			?>
			</div>
			</div>

			<div id="y">
				<div class="col-md-4 container" id="d" style="margin-top:50px;">
			<p style="font-size:30px;color:#000;">SELECT CATEGORY</p>
			<?php $gdfgt=$_GET['id'];?>
			<form action="commondash.php?id=<?php echo $gdfgt;?>" method="post">
	

		<?php 
			$god=$_GET['id'];
				$qry1="select id,subcatname from add_subcat where pcatid='".$god."'";
				$data1=mysqli_query($con,$qry1);
				while($row1=mysqli_fetch_array($data1))
				{	
					
		?>
					<input type="radio" name="wo" value="<?php echo $row1[0];?>" style="margin-left:15px;">
					<span style="font-weight:bolder;"><?php echo $row1[1]; ?></span><br>
		
		<?php 
					$qry2="select id,suprcatname from super_subcat where subcatid='".$row1[0]."'";
					$data2=mysqli_query($con,$qry2);
					while($row2=mysqli_fetch_array($data2))
						{
		?>
							
							<input type="radio"  name="wo" value="<?php echo $row2[0];?>" style="margin-left:35px;">
							<?php echo $row2[1];?><br>
							
		<?php 
						}
		?>
		<?php 
				}
		?>
		
		<input type="submit" name="adsubmit" value="Submit" class="btn btn-sm btn-primary">
	</form>
		</div>
		<div class="col-md-8">
			<?php
			

			if(isset($_POST['adsubmit']))
			{
				$_SESSION['s_id']=@$_POST['wo'];
				$kjp=$_GET['id'];
				//echo $kjp;
			
				?>
				<form action="commondash.php?id=<?php echo $kjp;?>" method="post" enctype="multipart/form-data">  
					
						<label>1.Name:</label><textarea rows="5" cols="80" style="display:block;" name="name"></textarea>
						<label>2.Price:</label><input type="text" style="display:block;" name="price">
						<label>3.Description:</label><textarea rows="6" cols="80" style="display:block;" name="desc"></textarea>
						<label>4.Model Description:</label><textarea rows="6" cols="80"style="display:block;" name="model"></textarea>
						<label>5.Suggestion(To Wear With):</label><textarea rows="6" cols="100"style="display:block;" name="towearwith"></textarea>
						<label>6.Material:</label><textarea rows="6" cols="100"style="display:block;" name="material"></textarea>
						<label>7.Color:</label><input type="text" name="color"><br>
						<label>8.Brand:</label><input type="text" name="brand"><br>
						<label>9.Size:</label><input type="text" name="size"><br>
						<label>10.photo:</label><input type="file" name="up">
						<label>11.photo1:</label><input type="file" name="up1">
						<label>12.photo2:</label><input type="file" name="up2">
						<label>13.photo3:</label><input type="file" name="up3">
						<input type="hidden" name="hidenid" value="<?php echo $_POST['wo'] ?>">
						<input type="submit" name="asubmit" value="Submit" class="btn btn-sm btn-primary">
					</form>
					<?php
			}
					
				?>
		</div>
		<?php
		if(isset($_POST['asubmit']))
		{
		$name1=$_POST['name'];
		$material=$_POST['material'];
		$size=$_POST['size'];
		$brand=$_POST['brand'];
		$hidenid=$_POST['hidenid'];
		$price=$_POST['price'];
		$descrp1=$_POST['desc'];
		$model=$_POST['model'];
		$towearwith=$_POST['towearwith'];
		$color=$_POST['color'];
		$photo=basename($_FILES['up']['name']);
		$photo1=basename($_FILES['up1']['name']);
		$photo2=basename($_FILES['up2']['name']);
		$photo3=basename($_FILES['up3']['name']);
		$yo=$_SESSION['maincatid'];
		$qry7="select id from add_subcat where id='".$_SESSION['s_id']."'";
		$res7=mysqli_query($qry7);
		while($row7=mysqli_fetch_array($res7))
		{
		$subcat_id=$row7[0];
		}
		$qry1="select id from super_subcat where id='".$_SESSION['s_id']."'";
		$res1=mysqli_query($qry1);
		while($row1=mysqli_fetch_array($res1))
		{
		$sprcat_id=$row1[0];
		}
		
		$cmd3="insert into products(subcat_id,sprcat_id,newcat_id,name,price,color,brand,size,description,model,towearwith,photo,photo1,photo2,photo3,hiddenid,
			material) value('$subcat_id','$sprcat_id','$yo','$name1','$price','$color','$brand','$size','$descrp1','$model','$towearwith','$photo'
			,'$photo1','$photo2','$photo3','$hidenid','$material')";
		
		if(mysqli_query($cmd3))
		{
			?><script>alert("Product Added");</script>
			<script>window.location='commondash.php?id=<?php echo $_SESION['maincatid']?>';</script>
			<?php
			
			header('commondash.php?id=<?php echo $_SESSION[maincatid]?>');
		}
		else{
			?><script>alert(<?php mysqli_error(); ?>);</script><?php
		}
		move_uploaded_file($_FILES['up']['tmp_name'],"images/products/".$photo);
		move_uploaded_file($_FILES['up1']['tmp_name'],"images/products/".$photo1);
		move_uploaded_file($_FILES['up2']['tmp_name'],"images/products/".$photo2);
		move_uploaded_file($_FILES['up3']['tmp_name'],"images/products/".$photo3);
		}	
		
		?>
	</div><!--id=#y(add product)-->
	</div>
	
	<div id="comp1"><!--companies addition-->
		<div class="col-md-4 col-md-offset-4" style="margin-top:20px;">
			<form action="commondash.php" method="post" enctype="multipart/form-data">
			<input type="text" required name="brandname"placeholder="Write Company Name" style="border-top:0px;border-left:0px;border-right:0px;width:100%;border-bottom:2px solid red;font-size:20px;"><br>

			<br>
			<textarea rows="4" cols="50"required name="descrp" placeholder="Write Description Line" style="width:100%;border:2px solid red;font-size:20px;"></textarea><br>
			<br>
			<input type="file" name="upldp"/>
			
			<input type="submit" name="sub4" value="Submit" style="margin-top:15px;" class="btn btn-md btn-primary s"/>
		</form>	
		<?php

		if(isset($_POST['sub4']))
		{
			$qry="select id from new_category where id=".$_SESSION['maincatid'];
			$res=mysqli_query($con,$qry);
			while($row=mysqli_fetch_array($res))
			{
				$maincatid=$row[0];
			
		$name=$_POST['brandname'];
		$descrp=$_POST['descrp'];
		$photo=basename($_FILES['upldp']['name']);
		$cmd="insert into companies(maincat_id,name,photo,descrp_line) values('$maincatid','$name','$photo','$descrp')";
		if(mysqli_query($cmd))
		{
		move_uploaded_file($_FILES['upldp']['tmp_name'],"images/".$photo);
		}
		else
		{
			echo mysqli_error();
		}
	 }
	}
		?>
	</div>

	</div>
	</body>
	</html>