		
<?php
include('connection.php');

	$id = $_GET['$id'];

		$sql="delete from about_us_qualities where id =$id";
				$success=mysql_query($sql);
				if($success)
				{
				 	?>
						<script>
							alert('Information deleted Permanently');
        					window.location.href='shabot_qual.php?success';
        				</script>
					<?php
					}
				else
					{
						

						?>
							<script>
									alert('Information cant be deleted');	
        							window.location.href='shabot_qual.php?failed';
        					</script>
						<?php
					
					}

	 	
	?>