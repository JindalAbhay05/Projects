<?php
					$cn=mysqli_connect("localhost","root","","youngsters");
						//mysqli_select_db("youngsters",$cn);
						
						$cmde="select id,name from new_category where id='$_GET[mainid]'";
						$rese=mysqli_query($cn,$cmde);
						while($rowe=mysqli_fetch_array($rese))
						{
					?>

					<p style="font-weight:bolder;font-size:20px;" class="abc"><?php echo $rowe[1];?></p>
					<hr>
					<?php
					}
					?>

					<?php
					//echo $_GET['brid'];
					$ght="select id,name from companies where id='".$_GET['brid']."'";
					$tyh=mysqli_query($cn,$ght);
					while($uyt=mysqli_fetch_array($tyh)) 
					{
						$kjh=$uyt[1];
						//echo $kjh;	
					}
					$cmd10="select id,newcat_id,name,price,brand,description,photo from products where brand='".$kjh."'";
						$res10=mysqli_query($cn,$cmd10);
						$c=0;
						while($row10=mysqli_fetch_array($res10))
						{
								$c+=1;
					?>
					
										
							<a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">
								
								<div width="150px" id="nam<?php echo $c;?>" class="col-md-3 abhay" style="padding-left:0px;padding-right:0px;">
						<center><img src="images/products/<?php echo $row10[6];?>" width="190px" height="238"></center>
					
						<div class="as" style="margin-top:5px;">
							<center><a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>"class="q">BUY NOW</a>
								<a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>" class="q1">QUICK VIEWS</a></center>
						</div>
						<center><p class="r" type="margin-bottom:0px;font-weight:bolder;"><?php echo $row10[2];?></p>
						<p class="rs" style="margin-top:0px;font-weight:bolder;margin-top:3px;">Rs <?php echo $row10[3];?></p></center>
						<div class="siz">
							
							<a style="margin-left:100px;text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">S</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">M</a>
							<a style="text-decoration:none;"href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">L</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">XL</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">XXl</a>
						
						</div>
					</div>
				
				</a>
					<?php
					$c++;
						}
						?>

<script>
		$(document).ready(function(){
			$(".as").hide();
			$(".siz").hide();

			var id;
			$(".abhay").hover(function(){

				 id=this.id;

						$("#"+id+" .r").hide();
						$("#"+id+" .as").show();
						$("#"+id+" .siz").show();
			
				});

					$(".abhay").mouseleave(function(){
						
						$("#"+id+" .r").show();
						$("#"+id+" .as").hide();
						$("#"+id+" .siz").hide();
					});
		});
		</script>		