<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
if(isset($_GET['mainid']))
{
	 
	$_SESSION['maincatid']=$_GET['mainid'];

}
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<script src="css/jquery.min.js"></script>
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<div class="main">
			<div>
			<?php
			include('menu2.php');
			?>
			</div>
			<div class="col-md-8">
					<div>
						<?php
						$mainctid=$_SESSION['maincatid'];
						
						$cmd="select photo1 from new_category where id=$mainctid";
						$res=mysqli_query($con,$cmd);
						while($row=mysqli_fetch_array($res))
						{
						?>
						<img style="margin-left:50px;" class="gnja" src="images/<?php echo $row[0]?>">
						<?php
						}
						?>
					</div>
					<div style="margin-bottom:30px;">
						<p style="font-weight:bolder;font-size:18px;color:#000;padding-bottom:0px;margin-left:15px;">#FEATURED</p>
 				<span style="color:grey;margin-left:15px;">Sunny Days Are here!</span>
					</div>
					<div>
						<?php
						$mainctid=$_SESSION['maincatid'];

						$qry="select maincat_id,name,photo,descrp_line,id from companies where maincat_id=$mainctid";
						$res=mysqli_query($con,$qry);
						while($row1=mysqli_fetch_array($res))
						{
						?>
					<a href="designing.php?brid=<?php echo $row1[4];?>&mainid=<?php echo $row1[0];?>"><div class="col-md-6" style="margin-bottom:20px;">
 					<div class="v"  style="overflow:hidden;">
 						<img width="350px" height="197px" src="images/<?php echo $row1[2];?>" class="x">
 					</div>
 					<div class="text-center">
 						<p style="font-weight:bolder;font-size:15px;color:#000;"><?php echo $row1[1];?></p>
 						<span style="color:grey;"><?php echo $row1[3];?></span>
 					</div>
 				</div></a>
 				<?php
 						}
 				?>
 				
 			</div>
				</div>
				<div class="col-md-4">
					<ul class="liste">
						<?php
          $cmd2="select id,subcatname from add_subcat where pcatid=$_SESSION[maincatid]";
          $res2=mysqli_query($con,$cmd2);
          while($row2=mysqli_fetch_array($res2))
          {
          	$main=$_SESSION['maincatid'];
            $id1=$row2[0];
            
          ?>
						<li><a href="designing.php?subid=<?php echo $id1;?>&mainid=<?php echo $main; ?>" style="font-weight:bolder;color:#000;"><?php echo $row2[1];?></a>
							 <ul style="margin-top:10px;">
							 	<?php
                   
                      $cmd3="select id,suprcatname from super_subcat where subcatid='$id1'";
                      $res3=mysqli_query($con,$cmd3);
                      while($row3=mysqli_fetch_array($res3))
                      {
                      ?>
                    <li><a href="designing.php?sprid=<?php echo $row3[0];?>&mainid=<?php echo $main; ?>" style="color:#da9a9a9;"><?php echo $row3[1];?></a></li>
                    <?php
                    }
                  
                    ?>
                    
                </ul>
                <?php
            		}
                ?>
						</li>
					</ul>
				</div>
			</div>
	</body>
</html>