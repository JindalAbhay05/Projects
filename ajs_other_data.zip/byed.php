<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<script src="css/jquery.min.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$("#recrd").click(function(){
				$("#rerd").slideToggle();
			});
		});
		</script>
</head>
<body>
	<div>
		<?php
		include('menu2.php');
		//include('backendmenu.php');
		?>
	</div>
	<div>
		
			<center><a class="text-center abc" id="recrd" ><i class="fa fa-archive" aria-hidden="true" style="font-size:30px;"></i>
<br>
					<span style="color:black;font-weight:bolder;">Record</span><br>
					All the record <br>of people <br>buying.

				</a></center>
		</div>
		<hr> 	
		<hr>	
		<div id="rerd"><!--all record-->
			
			<?php
			$con=mysqli_connect("localhost","root","","youngsters");
			///mysqli_select_db("youngsters",$con);
			$tye="select prod_id,name,price,phoneno,prod_name,address from record"; 
			$ui=mysqli_query($con,$tye);?>
			<table class="table" border='1'>
			<tr class="thead">
			<th>Person Name</th>
			<th>Phone Number</th>
			<th>Address</th>
			<th>Product Name</th>
			<th>Product Id</th>
			<th>Price</th>
			</tr>
			<?php
			while($uop=mysqli_fetch_array($ui))
			{
				?>
			<tr>
			<td><?php echo $uop[1]; ?></td>
			<td><?php echo $uop[3]; ?></td>
			<td><?php echo $uop[5]; ?></td>
			<td><?php echo $uop[4] ?></td>
			<td><?php echo $uop[0] ?></td>
			<td><?php echo $uop[2] ?></td>
			</tr>
			<?php
			}
			?>
			</table>
		
			
		</div>
		
	</body>
</html>
