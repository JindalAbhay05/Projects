<?php
include('connection.php');
session_start();
  if(isset($_POST['op']))
  { 
    $uname=$_POST['name'];
    $upassword=$_POST['pass'];
    $qry="select id,username from admin_login where username='$uname' AND password='$upassword'";
    $data=mysqli_query($qry);
    $counter=mysqli_num_rows($data);
    if($counter>0)
    {
      $row=mysqli_fetch_array($data);
      $_SESSION['aid']=$row[0];
      
      $_SESSION['aname']=$row[1];
      ?>
      <script type="text/javascript">
          window.location.href="index.php?id=<?php echo $row[0];?>&&name=<?php echo $row[1];?>";
      </script>
      <?php
      $qrey="update admin_login SET last_login_t_d= NOW() where id=".$_SESSION['aid']."";
      mysqli_query($qrey);
    }
    else{
      ?>
      <p style="color:#a9a9a9;font-size:20px;text-align:center;margin-top:50px;">Sorry you are not 'Enabled' by the admin yet!! Try again later...</p>
      <?php
    }
  }
  else
  {
    header("location:logidffg.php?id=1000");
  }
  

?>