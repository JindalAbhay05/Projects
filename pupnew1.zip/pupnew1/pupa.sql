-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2019 at 02:10 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pupa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_logins`
--

CREATE TABLE `admin_logins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` varchar(10) NOT NULL,
  `profilepic` varchar(100) NOT NULL,
  `digsignature` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_logins`
--

INSERT INTO `admin_logins` (`id`, `username`, `password`, `level`, `profilepic`, `digsignature`) VALUES
(1, 'mahesh', 'mahesh', 'Level0', 'motivational-wallpaper-15.jpg', 'War-inspirational-quote-with-wallpaper-hd.jpg'),
(2, 'jordan', 'jordan', 'Level1', 'ipad23.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png'),
(3, 'harman', 'harman', 'Level3', '469415.jpg', '160265.jpg'),
(5, 'komal', 'komal', 'Level2', 'Not-Impossible-2.jpg', 'motivational-wallpaper-15.jpg'),
(8, 'nime', 'nime', 'Level0', '458508.jpg', '467022.jpg'),
(9, 'mmm', 'bsjfsjd', 'Level0', 'WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg'),
(10, 'vsdjf', 'bfjdfbfd', 'Level0', 'WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_info`
--

CREATE TABLE `candidate_info` (
  `regno` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `foreign_student_cat` varchar(10) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `p_nationality` varchar(100) NOT NULL,
  `p_state` varchar(100) NOT NULL,
  `p_city` varchar(100) NOT NULL,
  `p_district` varchar(100) NOT NULL,
  `p_country` varchar(100) NOT NULL,
  `p_pincode` int(11) NOT NULL,
  `p_address` varchar(200) NOT NULL,
  `c_nationality` varchar(100) NOT NULL,
  `c_state` varchar(100) NOT NULL,
  `c_city` varchar(100) NOT NULL,
  `c_district` varchar(100) NOT NULL,
  `c_country` varchar(100) NOT NULL,
  `c_pincode` int(11) NOT NULL,
  `c_address` varchar(200) NOT NULL,
  `phone` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `is_punj_examamin_passed` varchar(50) NOT NULL,
  `level_of_punj_examin` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `profilepicture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidate_info`
--

INSERT INTO `candidate_info` (`regno`, `name`, `gender`, `category`, `foreign_student_cat`, `father_name`, `mother_name`, `p_nationality`, `p_state`, `p_city`, `p_district`, `p_country`, `p_pincode`, `p_address`, `c_nationality`, `c_state`, `c_city`, `c_district`, `c_country`, `c_pincode`, `c_address`, `phone`, `mobile`, `is_punj_examamin_passed`, `level_of_punj_examin`, `dob`, `email`, `profilepicture`) VALUES
('1203', 'fsdfsfs', 'Female', 'Sc', 'No', 'sdvafvafb', 'vsavab', 'indian', 'punjab', 'patiala', 'patialaa', 'india', 147001, 'dfdsfsgg', 'indian', 'punjab', 'patiala', 'patialaa', 'india', 147001, 'dfdsfsgg', 2147483647, 2147483647, 'Yes', '10th', '1991-05-20', 'taru@gmail.com', 'Screenshot (2).png'),
('123456799', 'gvuygufvyggytf', 'Male', 'General', 'Yes', 'ffbfjdbgk', 'vvtcytchytch', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'rdytfgfvku', 'dcfctftfvjyyjj', 'fgcgvkvtctmgmk', 151001, 'ygyhygvyhyvygbyhygyub byg', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'rdytfgfvku', 'dcfctftfvjyyjj', 'fgcgvkvtctmgmk', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-03-15', 'sfsdf@gmail.com', 'http://localhost/CodeIgniter/./profilepicture/'),
('151001', 'fbjhfbgk', 'Male', 'General', 'Yes', 'ffbfjdbgk', 'fbvjfdgbkdjf', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-03-21', 'sfsdf@gmail.com', 'http://localhost/pupc/./profilepicture/4634676.jpg'),
('15100105', 'fbjhfbgk', 'Male', 'General', 'Yes', 'ffbfjdbgk', 'fbvjfdgbkdjf', 'cgvhvyfu tfytfjm', 'hvdfdjbfhj', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 'cgvhvyfu tfytfjm', 'hvdfdjbfhj', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-03-08', 'ab@gmail.com', 'http://localhost/CodeIgniter/./profilepicture/'),
('15100111', 'fbjhfbgk', 'Male', 'General', 'Yes', 'ffbfjdbgk', 'fbvjfdgbkdjf', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'dhjvdfhj', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 'cgvhvyfu tfytfjm', 'yttfyfuyfjfjy', 'dhjvdfhj', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-03-27', 'sfsdf@gmail.com', 'http://localhost/pupc/./profilepicture/abhay Project.pdf'),
('1510012', 'fbjhfbgk', 'Male', 'General', 'Yes', 'chvhvujbjgk', 'vvtcytchytch', 'hfbhfdjdb', 'yttfyfuyfjfjy', 'rdytfgfvku', 'bhfvbdjfbj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 'hfbhfdjdb', 'yttfyfuyfjfjy', 'rdytfgfvku', 'bhfvbdjfbj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-03-06', 'sfsdf@gmail.com', 'http://localhost/pupc/./profilepicture'),
('15254d8', 'gvuygufvyggytf', 'Male', 'General', 'Yes', 'fbhdbfjh', 'fhbfhbfjhbj', 'hfbhfdjdb', 'hvdfdjbfhj', 'dhjvdfhj', 'bhfvbdjfbj', 'fgcgvkvtctmgmk', 15101, 'ygyhygvyhyvygbyhygyub byg', 'hfbhfdjdb', 'hvdfdjbfhj', 'dhjvdfhj', 'bhfvbdjfbj', 'fgcgvkvtctmgmk', 15101, 'ygyhygvyhyvygbyhygyub byg', 2147483647, 1516478965, 'Yes', '10th', '2019-04-26', 'asd@gmail.com', 'WWW.YIFY-TORRENTS.COM.jpg'),
('4564859', 'jordan', 'Male', 'General', 'Yes', 'aaasss', 'hdssh', 'hfbhfdjdb', 'fthgtrhdfdfg', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 'hfbhfdjdb', 'fthgtrhdfdfg', 'rdytfgfvku', 'dcfctftfvjyyjj', 'bjfbdfkjgbdkfb', 151001, 'ygyhygvyhyvygbyhygyub byg', 1546321548, 2147483647, 'Yes', '10th', '2019-04-10', 'abh@gmail.com', '392885.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `regno` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `foreign_student_cat` varchar(10) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `p_nationality` varchar(100) NOT NULL,
  `p_state` varchar(100) NOT NULL,
  `p_city` varchar(100) NOT NULL,
  `p_district` varchar(100) NOT NULL,
  `p_country` varchar(100) NOT NULL,
  `p_pincode` varchar(100) NOT NULL,
  `p_address` varchar(200) NOT NULL,
  `c_nationality` varchar(100) NOT NULL,
  `c_state` varchar(100) NOT NULL,
  `c_city` varchar(100) NOT NULL,
  `c_district` varchar(100) NOT NULL,
  `c_country` varchar(100) NOT NULL,
  `c_pincode` int(11) NOT NULL,
  `c_address` varchar(200) NOT NULL,
  `phone` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `is_punj_examamin_passed` varchar(10) NOT NULL,
  `level_of_punj_examin` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `profilepicture` varchar(200) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `exempted_fee` varchar(100) NOT NULL,
  `jrf_holder` varchar(100) NOT NULL,
  `supervisor` varchar(100) NOT NULL,
  `select_co_supervisor` varchar(100) NOT NULL,
  `mode_of_phd` varchar(50) NOT NULL,
  `is_coursework_done` varchar(10) NOT NULL,
  `uni_reg_number` int(11) NOT NULL,
  `fellowship_id` int(11) NOT NULL,
  `research_title` varchar(200) NOT NULL,
  `university_name` varchar(100) NOT NULL,
  `dept_or_place` varchar(100) NOT NULL,
  `name_of_researcher` varchar(100) NOT NULL,
  `name_of_the_guide` varchar(100) NOT NULL,
  `type_of_degree` varchar(10) NOT NULL,
  `dobb` date NOT NULL,
  `awarded_date` date NOT NULL,
  `completed_date` int(11) NOT NULL,
  `title_with_subtitle` varchar(100) NOT NULL,
  `abstract` varchar(500) NOT NULL,
  `first_level_of_subject` varchar(100) NOT NULL,
  `second_level_of_subject` varchar(100) NOT NULL,
  `third_level_of_subject` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `submitted_by` varchar(100) NOT NULL,
  `copyrights` varchar(100) NOT NULL,
  `size` varchar(50) NOT NULL,
  `dimensions` varchar(100) NOT NULL,
  `accompny_material` varchar(100) NOT NULL,
  `files1_titles` varchar(200) NOT NULL,
  `files2_certificates` varchar(200) NOT NULL,
  `files3_preiminary_pages` varchar(200) NOT NULL,
  `files4_chapter1` varchar(200) NOT NULL,
  `files5_chapter2` varchar(200) NOT NULL,
  `files6_chapter3` varchar(200) NOT NULL,
  `files7_chapter4` varchar(200) NOT NULL,
  `files8_chapter5` varchar(200) NOT NULL,
  `files9_chapter6` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`regno`, `name`, `gender`, `category`, `foreign_student_cat`, `father_name`, `mother_name`, `p_nationality`, `p_state`, `p_city`, `p_district`, `p_country`, `p_pincode`, `p_address`, `c_nationality`, `c_state`, `c_city`, `c_district`, `c_country`, `c_pincode`, `c_address`, `phone`, `mobile`, `is_punj_examamin_passed`, `level_of_punj_examin`, `dob`, `email`, `profilepicture`, `faculty`, `department`, `exempted_fee`, `jrf_holder`, `supervisor`, `select_co_supervisor`, `mode_of_phd`, `is_coursework_done`, `uni_reg_number`, `fellowship_id`, `research_title`, `university_name`, `dept_or_place`, `name_of_researcher`, `name_of_the_guide`, `type_of_degree`, `dobb`, `awarded_date`, `completed_date`, `title_with_subtitle`, `abstract`, `first_level_of_subject`, `second_level_of_subject`, `third_level_of_subject`, `language`, `submitted_by`, `copyrights`, `size`, `dimensions`, `accompny_material`, `files1_titles`, `files2_certificates`, `files3_preiminary_pages`, `files4_chapter1`, `files5_chapter2`, `files6_chapter3`, `files7_chapter4`, `files8_chapter5`, `files9_chapter6`) VALUES
(0, '', 'Male', 'General', 'Yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 0, 'Yes', '10th', '1970-01-01', '', '', '', '', '', '', '', '', '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(226, 'rfjn', 'Male', 'General', 'Yes', 'sfjskj', 'fbjdedfbj', 'gbrjkgbjk', 'ebjedkjfj', 'dgkdj', 'jefbdjkfj', 'fbdjbke', '151001', 'fgnrkrjgnejknkjkbjk fgwjgfkj gfkjfg jktg jwk', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 151001, 'fgnrkrjgnejknkjkbjk fgwjgfkj gfkjfg jktg jwk', 1234567897, 123456758, 'Yes', '10th', '2019-02-14', 'rbhjbrjm@gmail.com', 'precedence.gif', 'fbejk', 'krjrkj', 'jefbdjkfj', 'Yes', 'jefbdjkfj', 'jefbdjkfj', 'Regular', 'Yes', 23233, 59, 'jefbdjkfj', 'Punjabi University,Patiala', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'Phd', '2019-02-14', '2019-02-14', 2019, 'jefbdjkfj', 'jefbdjkfjjefbdjkfjjefbdjkfjjefbdjkfjjefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', 'jefbdjkfj', '420', '400x500', 'jefbdjkfjjefbdjkfj', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif', 'precedence.gif'),
(1231, 'abhay', 'Male', 'General', 'Yes', 'heuigfyu', 'bfhfbdrhfjg', 'hugiuf', 'dfhgiudf', 'hgij', 'guhiu', 'brgbru', 'bgjeiu', 'hgudhfiguhrdiuhu', 'jefguewi', 'bbfghj', 'bjhgb', 'hbfjgb', 'bejgbj', 0, 'jfbjdgjegkhjrhguh', 2147483647, 2147483647, 'Yes', '10th', '2019-02-21', 'abhay@lgmail.com', 'precedence.gif', '', '', '', '', '', '', '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `level0details`
--

CREATE TABLE `level0details` (
  `regno` varchar(20) NOT NULL,
  `file1` varchar(100) NOT NULL,
  `file2` varchar(100) NOT NULL,
  `file3` varchar(100) NOT NULL,
  `file4` varchar(100) NOT NULL,
  `file5` varchar(100) NOT NULL,
  `file6` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `level` varchar(20) NOT NULL,
  `temp` varchar(10) NOT NULL,
  `type_of_examination` varchar(30) NOT NULL,
  `datef` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level0details`
--

INSERT INTO `level0details` (`regno`, `file1`, `file2`, `file3`, `file4`, `file5`, `file6`, `comment`, `level`, `temp`, `type_of_examination`, `datef`) VALUES
('1024', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'yuhjh', 'Level0', 'Yes', 'synopsis', '2019-04-15'),
('1024mn4', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'ssgsvsg', 'Level0', 'Yes', 'synopsis', '2019-04-09'),
('112233', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'gg yff gfjytuk', 'Level0', 'Yes', 'synopsis', '2019-04-25'),
('1230f456', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'hkjhrkghk herhgrk hih k', 'Level0', 'Yes', 'Summary', '2019-04-10'),
('1231569', '392885.jpg', '462371.jpg', '', '', '', '', 'dsbfsjdf', 'Level0', 'Yes', 'sgfh', '2019-04-16'),
('123159', '392885.jpg', '462371.jpg', '', '', '', '', 'gsfskjdhfnks', 'Level0', 'Yes', 'fff', '0000-00-00'),
('12345', 'k_means clustering.docx', 'EDA2.docx', 'logistic_reg.pdf.docx', 'k_means clustering.docx', 'deep_leaning.pdf.docx', 'accuracy and matrics.docx', 'nfgrkdgnk,', 'Level0', 'Yes', '', '0000-00-00'),
('123df156', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'bkdfhbjfdkghu fghfiug haifuha ih', 'Level0', 'Yes', 'Seminar', '2019-06-19'),
('124', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'synopsis (special)', 'Level0', 'Yes', 'synopsis', '2019-04-18'),
('1245', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'uhdfsi', 'Level0', 'Yes', 'synopsis', '2019-04-24'),
('12456', 'EDA2.docx', 'accuracy and matrics.docx', 'Feature_eng (1).docx', 'knn1.docx', 'Decision_tree.docx', 'Decision_tree.docx', 'ndvdnk', 'Level0', 'Yes', '', '0000-00-00'),
('12478', 'WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', 'jbfkj jkg hjh jk', 'Level0', 'Yes', 'xyb', '2019-04-24'),
('14htm4', 'receipt.pdf', '', '', '', '', '', 'jghjgj', 'Level0', 'Yes', 'Seminar', '2019-06-12'),
('15237', 'Screenshot (6).png', 'Screenshot (7).png', '', '', '', '', 'ghdhsyuy6 ', 'Level0', 'Yes', 'Seminar', '2019-05-14'),
('157545', '462381.jpg', '470620.jpg', '', '', '', '', 'sgdfgdg', 'Level0', 'Yes', '', '0000-00-00'),
('15879', 'EDA2.docx', 'Feature_eng (1).docx', '', '', '', '', 'hkewhfewjk', 'Level0', 'Yes', '', '0000-00-00'),
('159951', 'abhay Project.pdf', 'abhay Project.pdf', '', '', '', '', 'dfusfi', 'Level0', 'Yes', '', '0000-00-00'),
('258357', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'hbjnkjnk j', 'Level0', 'Yes', 'PreSubmissionThesis', '2019-04-16'),
('268645', '462381.jpg', '479332.jpg', '', '', '', '', 'sgfdgdfgrefbe', 'Level0', 'Yes', '', '0000-00-00'),
('457p89', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'cjh jhk l', 'Level0', 'Yes', 'Annual', '2019-04-30'),
('51c55d77', 'Screenshot (130).png', '', '', '', '', '', 'hffusdfsij', 'Level0', 'Yes', 'PreSubmissionThesis', '2019-04-09'),
('547kl8m', 'receipt.pdf', '', '', '', '', '', 'kmkomol', 'Level0', 'Yes', 'PreSubmissionThesis', '2019-06-26'),
('75258l6', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'dsdgsdgshb zsgvs', 'Level0', 'Yes', 'Seminar', '2019-04-16'),
('78945', 'knn1.docx', 'logistic_reg.pdf.docx', 'principal component analysis.docx', 'EDA1.docx', 'Feature_eng (1).docx', 'Decision_tree.docx', 'nfkwntlkwml', 'Level0', 'Yes', '', '0000-00-00'),
('gh45f78', '', 'receipt.pdf', '', '', '', '', 'fdsgag', 'Level0', 'Yes', 'synopsis', '2019-07-31'),
('kj71gf', 'receipt.pdf', '', '', '', '', '', 'sgsefa', 'Level0', 'Yes', 'synopsis', '2019-06-24');

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE `main` (
  `file1` varchar(200) NOT NULL,
  `file2` varchar(200) NOT NULL,
  `file3` varchar(200) NOT NULL,
  `file4` varchar(200) NOT NULL,
  `file5` varchar(200) NOT NULL,
  `file6` varchar(200) NOT NULL,
  `level` varchar(10) NOT NULL,
  `temp` varchar(10) NOT NULL,
  `approve` varchar(10) NOT NULL,
  `disapprove` varchar(10) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `dlevel0` varchar(100) NOT NULL,
  `dlevel1` varchar(100) NOT NULL,
  `dlevel2` varchar(100) NOT NULL,
  `dlevel3` varchar(100) NOT NULL,
  `type_of_examination` varchar(30) NOT NULL,
  `datef` date NOT NULL,
  `regno` varchar(20) NOT NULL,
  `id` int(11) NOT NULL,
  `zerid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`file1`, `file2`, `file3`, `file4`, `file5`, `file6`, `level`, `temp`, `approve`, `disapprove`, `comment`, `dlevel0`, `dlevel1`, `dlevel2`, `dlevel3`, `type_of_examination`, `datef`, `regno`, `id`, `zerid`) VALUES
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level1', 'Yes', '', '', 'ssgsvsg', 'War-inspirational-quote-with-wallpaper-hd.jpg', '', '', '', 'synopsis', '2019-04-09', '1024mn4', 17, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level2', 'Yes', 'Yes', '', 'gg yff gfjytuk', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', 'motivational-wallpaper-15.jpg', '160265.jpg', 'synopsis', '2019-04-25', '112233', 18, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level0', 'Yes', '', '', 'cjh jhk l', 'War-inspirational-quote-with-wallpaper-hd.jpg', '', '', '', 'Annual', '2019-04-30', '457p89', 19, 1),
('WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', 'Level2', 'Yes', 'Yes', '', 'jbfkj jkg hjh jk', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', 'motivational-wallpaper-15.jpg', '', 'xyb', '2019-04-24', '12478', 20, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level2', 'Yes', 'Yes', 'Yes', 'hbjnkjnk j', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', '', '', 'PreSubmissionThesis', '2019-04-16', '258357', 21, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level1', 'Yes', 'Yes', '', 'dsdgsdgshb zsgvs', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', '', '', 'Seminar', '2019-04-16', '75258l6', 22, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level1', 'Yes', 'Yes', '', 'hkjhrkghk herhgrk hih k', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', '', '', 'Summary', '2019-04-10', '1230f456', 23, 1),
('WWW.YIFY-TORRENTS.COM.jpg', '', '', '', '', '', 'Level1', 'Yes', 'Yes', '', 'bkdfhbjfdkghu fghfiug haifuha ih', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', '', '', 'Seminar', '2019-06-19', '123df156', 24, 1),
('Screenshot (130).png', '', '', '', '', '', 'Level2', 'Yes', 'Yes', '', 'hffusdfsij', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', 'motivational-wallpaper-15.jpg', '', 'PreSubmissionThesis', '2019-04-09', '51c55d77', 25, 1),
('Screenshot (6).png', 'Screenshot (7).png', '', '', '', '', 'Level2', 'Yes', 'Yes', '', 'ghdhsyuy6 ', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', 'motivational-wallpaper-15.jpg', '', 'Seminar', '2019-05-14', '15237', 26, 1),
('receipt.pdf', '', '', '', '', '', 'Level1', 'Yes', 'Yes', '', 'jghjgj', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', '', '', 'Seminar', '2019-06-12', '14htm4', 27, 1),
('receipt.pdf', '', '', '', '', '', 'Level2', 'Yes', 'Yes', '', 'kmkomol', 'War-inspirational-quote-with-wallpaper-hd.jpg', '1 iEo70KVwcBIzQhQRlne8Aw.png', 'motivational-wallpaper-15.jpg', '', 'PreSubmissionThesis', '2019-06-26', '547kl8m', 28, 1),
('', 'receipt.pdf', '', '', '', '', 'Level1', 'Yes', '', 'Yes', 'fdsgag', '467022.jpg', '', '', '', 'synopsis', '2019-07-31', 'gh45f78', 29, 8),
('receipt.pdf', '', '', '', '', '', 'Level1', 'Yes', '', 'Yes', 'sgsefa', 'WWW.YIFY-TORRENTS.COM.jpg', '', '', '', 'synopsis', '2019-06-24', 'kj71gf', 30, 9);

-- --------------------------------------------------------

--
-- Table structure for table `registration_info`
--

CREATE TABLE `registration_info` (
  `uni_reg_no` int(11) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `exemptedfromfee` varchar(100) NOT NULL,
  `jrf_holder` varchar(10) NOT NULL,
  `supervisor` varchar(50) NOT NULL,
  `co_supervisor` varchar(100) NOT NULL,
  `mode_of_phd` varchar(100) NOT NULL,
  `is_course_w_done` varchar(100) NOT NULL,
  `fellowship_id` varchar(100) NOT NULL,
  `researchtitle` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_info`
--

INSERT INTO `registration_info` (`uni_reg_no`, `faculty`, `department`, `exemptedfromfee`, `jrf_holder`, `supervisor`, `co_supervisor`, `mode_of_phd`, `is_course_w_done`, `fellowship_id`, `researchtitle`) VALUES
(4564859, 'hrngjkr', 'dhffb', 'Yes', 'fvkk', 'hbeku', 'Regular', 'Yes', 'fb dfbd', '78', 'nfkjenfkjekfdgsd fxdfhbs');

-- --------------------------------------------------------

--
-- Table structure for table `synop`
--

CREATE TABLE `synop` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `degree` varchar(30) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `patrta` varchar(100) NOT NULL,
  `allotment` varchar(100) NOT NULL,
  `nigran` varchar(100) NOT NULL,
  `helper` varchar(100) NOT NULL,
  `reg_form` varchar(100) NOT NULL,
  `reg_fees` varchar(50) NOT NULL,
  `prof` varchar(100) NOT NULL,
  `karwahi` varchar(100) NOT NULL,
  `tip` varchar(100) NOT NULL,
  `help` varchar(100) NOT NULL,
  `noc` varchar(100) NOT NULL,
  `res` varchar(100) NOT NULL,
  `plang` varchar(100) NOT NULL,
  `ethical` varchar(100) NOT NULL,
  `temp` varchar(10) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `synop`
--

INSERT INTO `synop` (`id`, `regno`, `name`, `degree`, `dept`, `faculty`, `patrta`, `allotment`, `nigran`, `helper`, `reg_form`, `reg_fees`, `prof`, `karwahi`, `tip`, `help`, `noc`, `res`, `plang`, `ethical`, `temp`, `level`) VALUES
(1, '4564859', 'jordan', 'phd', 'dhffb', 'hrngjkr', 'synop', 'synop', 'synop', 'synop', 'V', 'synop', 'synop', 'synop', 'synop', 'synop', 'synop', 'synop', 'synop', 'synop', 'Yes', 'Level2');

-- --------------------------------------------------------

--
-- Table structure for table `thesis_detail`
--

CREATE TABLE `thesis_detail` (
  `uni_reg_no` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `abstract` varchar(500) NOT NULL,
  `levelone` varchar(100) NOT NULL,
  `leveltwo` varchar(100) NOT NULL,
  `levelthree` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `submitted_by` varchar(100) NOT NULL,
  `copyrights` varchar(100) NOT NULL,
  `files1` varchar(200) NOT NULL,
  `files2` varchar(200) NOT NULL,
  `files3` varchar(200) NOT NULL,
  `files4` varchar(200) NOT NULL,
  `files5` varchar(200) NOT NULL,
  `files6` varchar(200) NOT NULL,
  `files7` varchar(200) NOT NULL,
  `files8` varchar(200) NOT NULL,
  `files9` varchar(200) NOT NULL,
  `files10` varchar(200) NOT NULL,
  `files11` varchar(200) NOT NULL,
  `files12` varchar(200) NOT NULL,
  `files13` varchar(200) NOT NULL,
  `files14` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thesis_detail`
--

INSERT INTO `thesis_detail` (`uni_reg_no`, `title`, `abstract`, `levelone`, `leveltwo`, `levelthree`, `language`, `submitted_by`, `copyrights`, `files1`, `files2`, `files3`, `files4`, `files5`, `files6`, `files7`, `files8`, `files9`, `files10`, `files11`, `files12`, `files13`, `files14`) VALUES
(4564859, 'dfbgrdb', 'sgergr rer hs hsdfbgrdbdfbgrdbdfbgrdb', 'dhnfdh', 'gth ht', 'xbx', 'bfhjbfjebjkfh', 'dhcfh', 'cnfcngf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf', 'gate syllabus.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `upload_thesis`
--

CREATE TABLE `upload_thesis` (
  `uni_reg_no` int(11) NOT NULL,
  `uni_name` varchar(100) NOT NULL,
  `dept_place` varchar(100) NOT NULL,
  `name_of_researcher` varchar(100) NOT NULL,
  `name_of_guide` varchar(100) NOT NULL,
  `type_of_degree` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `awarded_date` date NOT NULL,
  `completed_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_thesis`
--

INSERT INTO `upload_thesis` (`uni_reg_no`, `uni_name`, `dept_place`, `name_of_researcher`, `name_of_guide`, `type_of_degree`, `dob`, `awarded_date`, `completed_date`) VALUES
(4564859, 'Punjabi University,Patiala', 'sdgvesgvs', 'sbsbsbsds', 'gjcghdhdh', 'Phd', '2019-04-18', '2019-04-18', 1997);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_logins`
--
ALTER TABLE `admin_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidate_info`
--
ALTER TABLE `candidate_info`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `level0details`
--
ALTER TABLE `level0details`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `main`
--
ALTER TABLE `main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration_info`
--
ALTER TABLE `registration_info`
  ADD PRIMARY KEY (`uni_reg_no`);

--
-- Indexes for table `synop`
--
ALTER TABLE `synop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thesis_detail`
--
ALTER TABLE `thesis_detail`
  ADD PRIMARY KEY (`uni_reg_no`);

--
-- Indexes for table `upload_thesis`
--
ALTER TABLE `upload_thesis`
  ADD PRIMARY KEY (`uni_reg_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_logins`
--
ALTER TABLE `admin_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `main`
--
ALTER TABLE `main`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `synop`
--
ALTER TABLE `synop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
