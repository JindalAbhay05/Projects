<?php 

include('connection.php'); 

if(isset($_POST['AAdDc']))
{
	
}

?>