		
<?php
include('connection.php');
	

	$id = $_GET['$id'];

		$sql="delete from users_tobe_called where id =$id";
				$success=mysql_query($sql);
				if($success)
				{
				 	?>
						<script>
							alert('Information deleted Permanently');
        					window.location.href='usrtybxc.php?success';
        				</script>
					<?php
					}
				else
					{
						

						?>
							<script>
									alert('Information cant be deleted');	
        							window.location.href='usrtybxc.php?failed';
        					</script>
						<?php
					
					}

	 	
	?>