<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
if(isset($_POST['justlovme']))
{
	$julovme=$_POST['lovjuname'];
$ulovname=$_POST['lovname'];
$ulovpass=$_POST['lovpass'];
$qry1="insert into admin_login(username,password,name) values('$ulovname','$ulovpass','$julovme')";
//mysqli_query($qry1);
if(mysqli_query($con,$qry1))
{
header("location:dashlogined.php");
}
else{
	echo mysqli_error();
}
}
?>