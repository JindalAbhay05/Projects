-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 03, 2016 at 12:43 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `youngsters`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_subcat`
--

CREATE TABLE IF NOT EXISTS `add_subcat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcatid` varchar(100) NOT NULL,
  `subcatname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `add_subcat`
--

INSERT INTO `add_subcat` (`id`, `pcatid`, `subcatname`) VALUES
(21, '7', 'Tops(Simple)'),
(23, '7', 'Tees'),
(24, '7', 'Jeans'),
(26, '7', 'Kurtas And Suits'),
(27, '7', 'Party Wear'),
(29, '12', 'T-shirts'),
(31, '12', 'Shirts'),
(32, '12', 'Jeans'),
(33, '12', 'Bottom Wear'),
(34, '12', 'Kurtas'),
(35, '12', 'Party Wear'),
(40, '15', 'Mens Wear'),
(42, '15', 'Womens Wear'),
(43, '15', 'Chronograph'),
(44, '15', 'Analog Watches'),
(45, '15', 'Chronograph'),
(46, '16', 'Mens Wear'),
(47, '16', 'Womens Wear');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`, `name`) VALUES
(1, 'admin', '123456', 'admin'),
(6, 'abc', '123654', 'abc'),
(7, 'Popey1@gmail.com', '456kfl', 'popey');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maincat_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `descrp_line` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `maincat_id`, `name`, `photo`, `descrp_line`) VALUES
(6, 12, '[IN]FORMALS', 'ucb.jpg', 'Yur Identity Redefined'),
(8, 12, 'H.E.', 'Feeds.jpg', 'Up town streetwear'),
(9, 12, 'Being Human', '6.jpg', 'Spring/Summer16 Colletion'),
(10, 12, 'Lee Cooper', 'lee-feed1464858444090_jv5nto.jpg', 'Spring/Summer16 Colletion'),
(11, 12, 'Ruosh', 'ruosh.jpg', 'New Arrivals'),
(12, 12, 'Daniel Klein', 'danielklein.jpg', 'Fashion for everyone from Daniel Klein'),
(13, 7, 'Ethnic Chic', 'Web-feeds1464255494480_gtqvsd.jpg', 'Collection Of Printed Long kutas'),
(14, 7, 'Premium Casuals', 'Web-feeds1464255264914_dndjcs.jpg', 'Spring/Summer16 Colletion'),
(15, 7, 'Pantaloons', '11463826282457-fb05.jpg', 'WOW Fashion At WOW Prices'),
(16, 7, 'Summer Is Calling', '11464011745303-imara.jpg', 'Latest Fusion Workwear'),
(17, 7, 'Carlton London', 'carltonlondon.jpg', 'Spring/Summer 16 Colletion'),
(19, 15, 'Titan Watches', '11466684467298-titan-feed.jpg', 'New Arrivals'),
(20, 15, 'Casio', 'index.jpg', '16 Summer Collection'),
(21, 15, 'Daniel Klein', 'danielklein.jpg', 'New Arrivals'),
(22, 15, 'Fasttrack', 'images.jpg', '16 Summer collection'),
(23, 15, 'Motorola', 'index12.jpg', 'Smart Watches On Your Hands'),
(24, 15, 'Maxima', 'index45.jpg', 'Best Watches'),
(25, 16, 'Roadsters', 'roadsters.jpg', 'Footwear');

-- --------------------------------------------------------

--
-- Table structure for table `new_category`
--

CREATE TABLE IF NOT EXISTS `new_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `photo1` varchar(200) NOT NULL,
  `photo2` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `new_category`
--

INSERT INTO `new_category` (`id`, `name`, `photo`, `photo1`, `photo2`) VALUES
(7, 'Women wear', 'ba 1 copy.jpg', 'newwomen_bottomwear.jpg', 'Kurtis_25March cpy.jpg'),
(12, 'Mens Wear', 'mensummer14june copy.jpg', 'Ether-Slideshow.jpg', '3_n.jpg'),
(15, 'Watches', 'wat copy.jpg', 'DT-Banner-E.jpg', 'watch.jpg'),
(16, 'Footwear', 'sycpy.jpg', '1MenFootwear_16MARCHcpy.jpg', '895_n.png');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subcat_id` int(11) NOT NULL,
  `sprcat_id` int(11) NOT NULL,
  `newcat_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `color` varchar(100) NOT NULL,
  `brand` varchar(200) NOT NULL,
  `size` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `model` varchar(1000) NOT NULL,
  `towearwith` varchar(1000) NOT NULL,
  `photo` varchar(300) NOT NULL,
  `photo1` varchar(300) NOT NULL,
  `photo2` varchar(300) NOT NULL,
  `photo3` varchar(300) NOT NULL,
  `hiddenid` int(11) NOT NULL,
  `material` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=564 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `subcat_id`, `sprcat_id`, `newcat_id`, `name`, `price`, `color`, `brand`, `size`, `description`, `model`, `towearwith`, `photo`, `photo1`, `photo2`, `photo3`, `hiddenid`, `material`) VALUES
(523, 21, 0, 7, 'RARE Coral Red Top', 599, 'red', 'Pantaloons', 'S', 'Coral red woven top, has a notched round neck, three-quarter bell sleeves, keyhole feature on the back with button-and-loop detail', 'The model (height 5,8 and chest 33) is wearing a size S', 'Look your casual best in this pretty top from Besiva. Wear it with a pair of denim shorts and flats for a complete ensemble.', '11448269368344-RARE-1.jpg', '11448269368278-RARE-W2.jpg', '11448269368207-RARE-Women-3.jpg', '11448269368091-RARE-4.jpg', 21, 'Polyester\r\nMachine-wash'),
(526, 0, 18, 7, 'Disney Mickey And Minnie Womens Top ', 599, 'green', 'Premium Casuals', 'S', 'Product Type - Officially Licensed DISNEY Graphic Tee\r\nColor - Green\r\nFit - Slim\r\nNeck & Sleeves - Scoop Neck & Short Sleeves\r\nGraphic Art - Captain America shield print on the front.', 'The model is wearing size S', 'Don a peppy look slipping into this Marvel tee from Yepme. Boasting Captain America shield print on the front, it is designed with a scoop neckline and short sleeves. Pair it up with a denim skirt and converse shoes for a sassy look.', '153580_ypxl_1.jpg', '153580_ypxl_2.jpg', '153580_ypxl_3.jpg', '153580_ypxl_5.jpg', 18, 'Fabric-Cotton\r\nMachine Wash'),
(528, 0, 18, 7, 'MARVEL- Captain America Shield Wome...', 599, 'green', 'Premium Casuals', 'S', 'Product Type - Officially Licensed DISNEY Graphic Tee,Color - Green,Fit - Slim,Neck & Sleeves - Scoop Neck & Short Sleeves,Graphic Art - Captain America shield print on the front.', 'The model is wearing size S', 'Don a peppy look slipping into this Marvel tee from Yepme. Boasting Captain America shield print on the front, it is designed with a scoop neckline and short sleeves. Pair it up with a denim skirt and converse shoes for a sassy look.', '153579_ypxl_1.jpg', '153579_ypxl_2.jpg', '153579_ypxl_3.jpg', '153579_ypxl_5.jpg', 18, 'Fabric - Cotton\r\n\r\nCare - Machine wash'),
(529, 0, 18, 7, 'DISNEY- Love Mickey Womens Top', 599, 'blue', 'Carlton London', 'S', 'Product Type - Officially Licensed DISNEY Graphic Tee,Color - Navy Blue,Fit - Slim\r\nNeck & Sleeves - Scoop Neck & Short Sleeves,Graphic Art - Mickey in love print on the front.', 'The model is wearing size S', 'Flaunt your casual side in style wearing this cute Disney tee from Yepme. Finished with a scoop neckline and short sleeves, it features Mickey in love print on the front. Club it with a pair of jeans and loafers for a flawless look.\r\n\r\n', '153583_ypxl_132.jpg', '153583_ypxl_365.jpg', '153583_ypxl_4545.jpg', '153583_ypxl_5545.jpg', 18, 'Fabric - Cotton,Care - Machine wash.'),
(530, 0, 15, 7, 'Yepme Scarlett Party Top - Coral', 1119, 'red', 'Carlton London', 'S', 'Product Type - Womens Top,Color - Coral,Pattern & Fit - Regular-fit top with coated contrast fabric collar, contrast panel on the front and golden zipper opening at the back,Neck & Sleeves - Point Collar & Sleeveless.', 'The Model is wearing size S', ' Flaunt a boho-chic style by clubbing it with a skinny-fit jeggings and pencil heels', '139410_ypxl_1.jpg', '139410_ypxl_2.jpg', '139410_ypxl_3.jpg', '139410_ypxl_4.jpg', 15, 'Fabric - Polyester,Care - Machine wash in cold water. Do not bleach. Tumble dry.\r\n\r\n'),
(532, 0, 17, 7, 'Yepme Sterry Party Blazer - Wine', 4799, 'grey', 'Carlton London', 'S', 'Product Type - Womens Blazer,Color - Wine,Pattern & Fit - Regular fit blazer with welt pockets having flaps, zipper detailing and shaped hem with lined body,Neck & Sleeves - Notch Collar & Full Sleeves.', 'This model has height 5,8, bust 34 and is wearing size S.', 'Style with rugged blue denims and solid crop tops for a stunning look', '139060_ypxl_1.jpg', '139060_ypxl_2.jpg', '139060_ypxl_3.jpg', '139060_ypxl_4.jpg', 17, 'Fabric - Polyester,Care - Dry Clean Only'),
(533, 0, 17, 7, 'Yepme Enya Casual Blazer - White', 2899, 'white', 'Carlton London', 'S', 'Product Type - Womens Blazer,Color - White,Pattern & Fit - Regular fit blazer with two patch pockets at front sides,Neck & Sleeves - Notch Collar & Full Sleeves.', 'This model has height 5,6, bust 33 and is wearing size S', 'Style with Yepme printed shirts and pencil skirts', '57134_ypxl_1.jpg', '57134_ypxl_2.jpg', '57134_ypxl_3.jpg', '57134_ypxl_4.jpg', 17, 'Fabric - Cotton,Care - Machine/Hand wash.'),
(534, 0, 20, 7, 'Yepme Baby Tee - Grey', 399, 'grey', 'Summer Is Calling', 'S', 'Product - Womens Tee,Color - Grey,Pattern & Fit - Slim-fit tee with Baby graphic print at front,Neck & Sleeves - Round Neck & Shot Sleeves.', 'Add elegance and style to your wardrobe with this graphic tee from the house of Yepme.\r\nThis T-Shirt incorporates a beautiful graphic design on chest, which further adds to its appeal. The price attached is affordable and comes in your budget.\r\nBring home quickly! Team up with Yepme colored shorts and wedges to adorn the perfect look of the season', 'Look nice with slim fit denims or colored pants along with matching bellies', '51638_ypxl_1.jpg', '51638_ypxl_2.jpg', '51638_ypxl_3.jpg', '51638_ypxl_4.jpg', 20, 'Fabric - Cotton Single jersey,Care - Machine/Hand Wash'),
(535, 0, 14, 7, 'Denim Soft Summer Jacket', 3733, 'blue', 'Summer Is Calling', 'S', 'Fabric:Tencel,Length:Waist Length,Sleeves:Full Sleeves,USP:Directly from Brand ,NEXT in UK -Prices are inclusive of duties', 'The model is wearing size S', 'Update your casual wardrobe this summer as you wear this jacket from the house of Next. Fashioned using tencel, this jacket will not fail to catch your fancy at a single glance. Wear this jacket over any plain top and enhance the look of your attire.', 'Next-Denim-Soft-Summer-Jacket-3502-2584012-1-pdp_slider_l.jpg', 'Next-Denim-Soft-Summer-Jacket-3503-2584012-2-pdp_slider_l.jpg', 'Next-Denim-Soft-Summer-Jacket-3502-2584012-1-pdp_slider_l.jpg', 'Next-Denim-Soft-Summer-Jacket-3503-2584012-2-pdp_slider_l.jpg', 14, 'Wash-,CareGentle Wash,Color-Blue,Style-Solid'),
(536, 0, 14, 7, 'Dark Grey Sleeveless Denim Jacket', 799, 'black', 'Summer Is Calling', 'S', 'Dark Grey Denim Jacket have     Crop length,Sleeveless design,Classic collar  Twin front flap pockets,Trendy buttons on the front, Rough tassels around the armholes,100% cotton fabric.\r\n', 'The model is wearing size S', 'Wear with black jeans and a pair of lack shoes.', 'Miss-Bennett-4-pdp_slider_l.jpg', 'Miss-Bennett-Londonslider_l.jpg', 'Miss-Bennett-Lop_slider_l.jpg', 'Miss-Bennettr_l.jpg', 14, 'Machine Cold Wash At 40 C,Do Not Bleach,Tumble Dry,Iron Medium Heat, Wash Inside Out.'),
(537, 23, 0, 7, 'Yepme Princess Tee - White', 399, 'White', 'Ethnic Chic', 'S', 'Product Type - Womens Tee,Color - White,Pattern & Fit - Slim-fit tee with Princess graphic at front,Neck & Sleeves - Round Neck & Short Sleeves.', 'The model is wearing size S.', 'Wear it with light wash denims or colored pants along with Yepme bellies.', '51697_ypxl_1.jpg', '51697_ypxl_2.jpg', '51697_ypxl_3.jpg', '51697_ypxl_4.jpg', 23, 'Fabric - Cotton Single Jersey,Care - Machine wash/Hand wash'),
(538, 23, 0, 7, 'Yepme Just Want Tee - Light Grey', 399, 'grey', 'Ethnic Chic', 'S', 'Product Type - Women Tee,Color - Grey,Pattern & Fit - Slim Fit tee with tee with Just Want graphic at front,Neck & Sleeves - Round Neck & Short Sleeves.', 'The model is wearing size S', 'Wear it with light wash denims or colored pants along with Yepme bellies', '51663_ypxl_1.jpg', '51663_ypxl_3.jpg', '51663_ypxl_4.jpg', '51663_ypxl_6.jpg', 23, 'Fabric - Cotton Single Jersey,Care - Machine wash/Hand wash.'),
(539, 0, 19, 7, 'Yepme Perry Polo Tee - Blue', 599, 'blue', 'Ethnic Chic', 'S', 'Product Type - Womens Tee,Color - Blue,Pattern & Fit - Slim-fit polo with open placket on the front,Neck & Sleeves - Collar & Short Sleeves.', 'The model is wearing size S', 'Opt for a cool and stylish look wearing this polo tee from Yepme. With open placket on the front, this T-shirt is crafted in fine cotton to keep you cool in hottest days. Club it with denim joggers and canvas shoes for an effortless look.\r\n\r\n', '150637_ypxl_1.jpg', '150637_ypxl_2.jpg', '150637_ypxl_3.jpg', '150637_ypxl_4.jpg', 19, 'Fabric - Cotton,Care - Machine wash in cold water. Do not bleach. Tumble dry.'),
(540, 0, 19, 7, 'Yepme Pow Tee - Blue', 399, 'blue', 'Ethnic Chic', 'S', 'Product Type - Womens Graphic Tee,Color - Blue,Pattern & Fit - Slim fit tee with Pow graphic at front,Neck & Sleeves - Round Neck & Short Sleeves.\r\n', 'The model is wearing size S.', 'Be a trendsetter by wearing this round neck graphic tee from the house of Yepme. Made from cotton this tee will certainly keep you comfortable all the day long, do not miss the tee this season.\r\n\r\nPair up with medium wash denim, Yepme flats and sports watch for a cool look.\r\n\r\n', '37923_ypxl_1.jpg', '37923_ypxl_2.jpg', '37923_ypxl_3.jpg', '37923_ypxl_6.jpg', 19, 'Fabric - Cotton Single Jersey,Care - Machine/Hand Wash.\r\n'),
(541, 24, 0, 7, 'Yepme Nicola Premium Denim - Golden', 1199, 'golden', 'Pantaloons', 'S', 'Product Type - Womens Denim,Color - Golden,Pattern & Fit - Slim-fit premium denim with five pocket styling, scoop pocket on the front including stylized coin pocket, decorative silver zipper at both thighs, zip fly with a button closure and brand label at back waistband,Waist - Mid-waist,Length - Full Length.', 'The model is wearing size S', 'Get your style statement underlined!\r\n\r\nFinished with zipper pocket styling on the front, these golden denims will give your look a stunning touch. Soft stretch construction ensures comfort and sexy fitting.\r\nPair this jeans effortlessly with an off-shoulder top and block heels to boost up your look', '136182_ypxl_1.jpg', '136182_ypxl_2.jpg', '136182_ypxl_4.jpg', '136182_ypxl_5.jpg', 24, 'Fabric - Cotton Polyester Lycra,Care - Machine wash in cold water. Do not bleach. Tumble dry.'),
(542, 24, 0, 7, 'Yepme Denise Capri - Beige', 749, 'golden', 'Pantaloons', 'S', 'Product Type - Womens Capri,Color - Beige,Pattern & Fit - Slim-fit capri with five pocket styling, two pockets at side front with coin pocket, two patch pocket at back, waistband with loops and button enclosure at waistband.', 'The model height is 5,8 and waist 28 (inches).', 'Let your bottom wear collection go colorful with our new range of capris!\r\n\r\nThese capris are not only enticing to see but also comfortable to wear, courtesy the stretchable fabric. The color scheme is prominent and gives you multiple teaming options.\r\n\r\nGo, grab it quickly and team up with Yepme solid shirts or ruffle top along with Yepme flats!', '51517_ypxl_1.jpg', '51517_ypxl_2.jpg', '51517_ypxl_3.jpg', '51517_ypxl_4.jpg', 24, 'Fabric - Cotton Lycra,Care - Machine wash. Dry in shade.'),
(553, 26, 0, 7, 'Erin Kurti White', 599, 'white', 'Premium Casuals', 'S', 'Product Type - Womens Kurti,color - White,Pattern & Fit - Regular-fit kurti with slit at neckline, contrast yoke and high-low front hemline,Neck & Sleeves - Round neck and Reglan sleeves. ', 'The model is wearing size S.', 'Slip into this charming creation and let your look go flawless!\n\nFeaturing an all-over print with contrasting yoke, this piece truly deserves your attention.\n\nTeam it with culottes for a stunning look and peep-toes!', '96907_ypxl_1.jpg', '96907_ypxl_2.jpg', '96907_ypxl_3.jpg', '96907_ypxl_4.jpg', 26, 'Fabric - Cotton,Care - Hand wash/Machine Wash'),
(554, 26, 0, 7, 'Mealany Salwar Suit - Peach', 5099, 'peach', 'Carlton London', 'S', 'Product Type - Salwar Kameez Set,Color - Peach,Kurti - Anarkali suit nylon net kurta with hand embroidered front and back neck plus bead work, gold laces at hem with silk dupion silk border and fully lined body,Churidar - Solid viscose lycra jersey churidar,Stole - Solid nylon net embroidered stole with gold lace and dupion silk edging,Kurti Length - 48 (Inches).', 'This model has height 5,7, bust 32 and is wearing size S.', 'Timeless elegance!\n\nBeautifully designed suit with beaded work at the neck along with churidar and dupatta, this anarkali suit set is a fabulous choice to look flawless.\n\nSimply partner this suit with danglers and pencil heels for a ravishing look!\n\n', '133523_ypxl_1.jpg', '133523_ypxl_2.jpg', '133523_ypxl_3.jpg', '133523_ypxl_4.jpg', 26, 'Care - Hand wash. Dry in shade,Style Tip - Wear danglers and high heels with this!'),
(555, 27, 0, 7, 'Janice PartyTop - Beige', 799, 'beige', 'Pantaloons', 'S', 'Product Type - Womens Top,Color - Beige & Black,Pattern & Fit - Regular-fit tank top with printed front and solid back having slit detailing,Neck & Sleeves - Round Neck & Short Sleeves..', 'This model has height 5,6, bust 32 and is wearing size S.', 'For an after-dark club party!\r\n\r\nSumptuously designed top with attractive print, it will lend a stunning finish to your party look.\r\n\r\nTeam it with a pencil skirt and high heel pumps for a sexy look!', '139422_ypxl_1.jpg', '139422_ypxl_2.jpg', '139422_ypxl_3.jpg', '139422_ypxl_4.jpg', 27, 'Fabric - Polyester,Care - Machine wash in cold water. Do not bleach. Tumble dry'),
(556, 27, 0, 7, 'Scarlett Party Top - Blue', 1199, 'blue', 'Summer Is Calling 	', 'S', 'Product Type - Womens Top,Color - Navy Blue,Pattern & Fit - Regular-fit top with coated contrast fabric collar, contrast panel on the front and golden zipper opening at the back,Neck & Sleeves - Point Collar & Sleeveless.', 'This model has height 5,7, bust 34 and is wearing size S.', 'Elegant & trendy!\r\n\r\nNothing can spruce up your look like this sleeveless top with a zipper closure at the back. Chic & stylish, it will be an ideal choice to attend a party at the club.\r\n\r\nFlaunt a chic style by clubbing it with skinny-fit jeggings and pencil heels!', '139412_ypxl_1.jpg', '139412_ypxl_2.jpg', '139412_ypxl_3.jpg', '139412_ypxl_4.jpg', 27, 'Fabric - Polyester,Care - Machine wash in cold water. Do not bleach. Tumble dry.'),
(557, 0, 24, 7, 'Marie Party Jumpsuit - Red', 2099, 'red', 'Carlton London', 'S', 'Product Type - Womens Jumpsuit,Color - Red,Pattern & Fit - Slim-fit jumpsuit with cut-out at waist, black knitted lace layer on top and concealed zipper closure at the back,Neck & Sleeves - Round Neck & Full Sleeves.', 'This model has height 5,8, bust 34 and is wearing size S.', 'Be adorable with lace!\r\n\r\nThis beautiful Youngsters creation having knitted lace layer on top is perfect for your gorgeous look.\r\n\r\nTeam it with a pair of pencil heels and bold lipstick for a pretty party look!', '139145_ypxl_1.jpg', '139145_ypxl_2.jpg', '139145_ypxl_3.jpg', '139145_ypxl_4.jpg', 24, 'Fabric - Polyester,Care - Machine wash in cold water. Do not bleach. Tumble dry.'),
(558, 40, 40, 15, 'Moto 360 (2nd Gen) Black Metal Smart Watch', 22799, 'black', 'Motorola', 'one size', 'Display: Digital\r\nDial shape: Round\r\nWater-resistant: Yes\r\nHeart rate monitor: Yes\r\nBluetooth: Yes\r\nCaller ID: Yes\r\nGPS tracking: Yes\r\nNotifications: Yes\r\nActivity tracking: No\r\nOS: Android Wear\r\nInternal memory: 4 GB', 'Compatible with iOS and Android\r\nProcessor name: Qualcomm Snapdragon 400 APQ8026\r\nProcessor speed: 1.2GHz\r\nNumber of Cores: Quad Core\r\nRam: 512MB\r\nInternal memory: 4GB\r\nDisplay resolution: 360 x 325pixel\r\nDisplay type: LCD\r\nOther watch functions: Wireless Charging with Charging Dock Included\r\nBluetooth version: v4.0\r\nMicrophone: 2 Microphones\r\nOther features: Dust and Water Resistance: IP67\r\nWarranty summary: 1 Year International Warranty.', 'Match it with any white and black jeans or pant to get a cool look with this youngsters watch.', '11449465970685-Moto.jpg', '11449465970619-Moto-360-2nd-Gen-Black-Metal-Smart-Watch-8301449465970352-2.jpg', '11449465970558-Moto-360-2nd-Gen-Black-Metal-Smart-Watch-8301449465970352-3.jpg', '11449465970430-Moto-360-2nd-Gen-Black-Metal-Smart-Watch-8301449465970352-5.jpg', 40, 'Dial material: Stainless steel\r\nStrap material: Metal\r\nWipe with a clean, dry cloth when needed'),
(559, 40, 40, 15, 'Daniel Klein Slim Men White Dial Watch DK10847-5', 1500, 'white', 'Daniel Klein', 'onesize', 'Dial width: 45 mm\r\nStrap width: 20 mm', 'Case style: Analogue watch, has a circular case, a fixed bezel and a stainless steel back\r\nDial style: White dial\r\nFeatures: A screw to reset time\r\nStrap style: Charcoal grey leather strap, secured with a tang clasp\r\nWater-resistant up to 30 m\r\nComes with an extra pair of fabric strap\r\nComes in a signature Daniel Klein case\r\nWarranty: 2 years for movement and battery only', 'This watch will be a classic addition to your timepiece collection and will look good when worn with your casual attire.', '11453190344170-Daniel-Klein-Slim-Men-White-Dial-Watch-DK10847-5-8221453190343788-1.jpg', '11453190344122-Daniel-Klein-Slim-Men-White-Dial-Watch-DK10847-5-8221453190343788-2.jpg', '11453190343942-Daniel-Klein-Slim-Men-White-Dial-Watch-DK10847-5-8221453190343788-5.jpg', '11453190343874-Daniel-Klein-Slim-Men-White-Dial-Watch-DK10847-5-8221453190343788-6.jpg', 40, 'Leather strip '),
(560, 0, 16, 7, 'Youngsters Veronica Printed Denim Shirt', 949, 'blue', 'Pantaloons', 'S', 'Product Type - Womens Shirt,Color - Blue,Pattern & Fit - Slim-fit printed denim shirt with patch pockets having flaps and button fastening on the front,Neck & Sleeves - Collar & Full Sleeves.', 'The model is wearing size S.', 'Denim shirt is a must have for this season!\r\n\r\nFeaturing an all-over print along with two pockets on the front, this stylishly designed button-down shirt is perfect to uplift your routine look.\r\n\r\nSpruce up its look by teaming with your favorite hue of jeans and canvas shoes!', '144498_ypxl_1.jpg', '144498_ypxl_2.jpg', '144498_ypxl_3.jpg', '144498_ypxl_4.jpg', 16, 'Fabric - Cotton,Care - Machine/Hand Wash.'),
(562, 29, 0, 12, 'Youngsters Tees', 288, 'Grey', 'Lee Cooper', 'S', 'Product Type - Officially Licensed CIVIL WAR Graphic Tee,Color - Grey,Fit - Slim,Neck & Sleeves - Round Neck & Short Sleeves,Graphic Art - Captain america and Iron Man face in star with Civil war logo on the front,Fabric - Cotton .', 'The model is wearing size S', 'Should wear it with 45', '153074_ypxl_1.jpg', '153074_ypxl_2.jpg', '153074_ypxl_3.jpg', '153074_ypxl_4.jpg', 29, 'good'),
(563, 46, 46, 16, 'Youngsters Casual Shoes - Tan', 199, 'Tan', 'Roadsters', 'S', 'Color: Tan\r\n\r\nClosing: Lace-up', 'Size:S', 'Wear with a olive color jeans or a pant.', '136120_ypxl_1.jpg', '136120_ypxl_2.jpg', '136120_ypxl_3.jpg', '136120_ypxl_4.jpg', 46, 'GOOD');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE IF NOT EXISTS `record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) NOT NULL,
  `newcat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `sprcat_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `phoneno` int(11) NOT NULL,
  `prod_name` varchar(300) NOT NULL,
  `address` varchar(700) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`id`, `prod_id`, `newcat_id`, `subcat_id`, `sprcat_id`, `name`, `price`, `phoneno`, `prod_name`, `address`) VALUES
(29, 535, 7, 0, 14, 'aj', 3733, 2134567896, 'Denim Soft Summer Jacket', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.'),
(30, 533, 7, 0, 17, 'aj', 2899, 2134567896, 'Yepme Enya Casual Blazer - White', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.'),
(31, 530, 7, 0, 15, 'aj', 1119, 2134567896, 'Yepme Scarlett Party Top - Coral', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.'),
(32, 521, 7, 21, 0, 'aj', 499, 2134567896, 'Harpa Women Black Printed Sheer Top', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.'),
(35, 523, 7, 21, 0, 'aj', 599, 2134567896, 'RARE Coral Red Top', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.'),
(36, 559, 15, 40, 40, 'navneet', 1500, 2147483647, 'Daniel Klein Slim Men White Dial Watch DK10847-5', 'hxxsvcshvhhbzz'),
(37, 541, 7, 24, 0, '', 1199, 0, 'Yepme Nicola Premium Denim - Golden', ''),
(38, 558, 15, 40, 40, '', 22799, 0, 'Moto 360 (2nd Gen) Black Metal Smart Watch', '');

-- --------------------------------------------------------

--
-- Table structure for table `slider_photos`
--

CREATE TABLE IF NOT EXISTS `slider_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `slider_photos`
--

INSERT INTO `slider_photos` (`id`, `photo`, `name`, `link`) VALUES
(4, 'aS1.jpg', 'woens clutches', ''),
(5, 'dd1.jpg', 'Western Wear', ''),
(6, '10watches.jpg', 'watches', ''),
(7, 'men_accessories_8june.jpg', 'men accessories', ''),
(8, 'womenewarivals3june.jpg', 'women arrivas', '');

-- --------------------------------------------------------

--
-- Table structure for table `super_subcat`
--

CREATE TABLE IF NOT EXISTS `super_subcat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcatid` varchar(200) NOT NULL,
  `subcatid` varchar(200) NOT NULL,
  `suprcatname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `super_subcat`
--

INSERT INTO `super_subcat` (`id`, `pcatid`, `subcatid`, `suprcatname`) VALUES
(14, '7', '21', 'Denim Jackets'),
(15, '7', '21', 'Party Wear Tops'),
(16, '7', '21', 'Shirts'),
(17, '7', '21', 'Blazers'),
(18, '7', '23', 'Marvel and Disney'),
(19, '7', '23', 'Polos Tees'),
(20, '7', '23', 'Graphic Tees'),
(21, '7', '23', 'Solid Tees'),
(23, '7', '27', 'Jumpsuits'),
(24, '7', '27', 'Jackets & Blazers'),
(34, '12', '29', 'Marvel and civil wars'),
(35, '12', '29', 'Tees'),
(36, '12', '29', 'Polos'),
(37, '12', '29', 'Henley Tees'),
(38, '12', '29', 'Full Sleeve Tees'),
(39, '12', '31', 'Party Wear'),
(40, '12', '31', 'Printed Shirts'),
(41, '12', '31', 'Kurta Shirts'),
(42, '12', '31', 'Denim Shirts'),
(43, '12', '31', 'Casual Shirts'),
(44, '12', '35', 'Blazers'),
(45, '12', '35', 'Tees & Polos'),
(46, '12', '35', 'Jackets'),
(47, '12', '35', 'Jeans'),
(48, '12', '35', 'Jackets'),
(64, '15', '40', 'Casual Watches'),
(65, '15', '40', 'Formal Watches'),
(66, '15', '40', 'Kids Watches'),
(67, '15', '40', 'Multifunctional'),
(70, '15', '42', 'Casual Watches'),
(71, '15', '42', 'Formal Watches'),
(72, '15', '42', 'Designer Watches'),
(73, '15', '42', 'Premium Watches'),
(74, '16', '46', 'Casual Shoes'),
(75, '16', '46', 'Mojaris'),
(76, '16', '46', 'Formal Shoes'),
(77, '16', '46', 'Sports Shoes'),
(78, '16', '46', 'Flip-Flops'),
(79, '16', '47', 'Mojaris'),
(80, '16', '47', 'Flats'),
(81, '16', '47', 'Boots'),
(82, '16', '47', 'Heels'),
(83, '16', '47', 'Flip-Flops');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `address` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_numbr` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `username`, `password`, `address`, `name`, `phone_numbr`) VALUES
(3, 'ajsA1@gmail.com', '789123', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.', 'aj', '2134567896'),
(4, 'anjA1@gmai.com', '45617869', '#456,green avenue,goli mar ke ,bathinda', 'anjana', '7894561235'),
(5, 'abnD@gmail.com', '123sd123', '#123ee46,phulan da baag,bathinda\r\n', 'sanju', '4567981235'),
(6, 'navz', '123456', 'hxxsvcshvhhbzz', 'navneet', '2314563542'),
(7, 'frhth', '123456', 'gulabgarh', 'jassi', '9454466566'),
(8, 'deepak kumar', '8427897988', 'babaf arid nagar', 'deepak kumar', '8427897988'),
(9, 'chirG GOYAL', '9790263650', 'bathinda jhujha rsingh nagar #20094', 'chirag goyal', '9780263650'),
(10, 'vdhfdjsk', 'hefjekdbfk', 'xgddhsjdu', 'adggsfkjhk', '784567999'),
(11, 'sahil', 'samsung', 'bathinda', 'sahil mittal', '7814122871');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE IF NOT EXISTS `user_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL,
  `phone_numbr` varchar(10) NOT NULL,
  `upass` varchar(10) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`id`, `uname`, `phone_numbr`, `upass`, `address`, `name`) VALUES
(4, 'ajsA1@gmail.com', '2134567896', '789123', '#116 ,green avenue,st.no.:5/2,near bibi wala chownk,bathinda.', 'aj'),
(5, 'anjA1@gmai.com', '7894561235', '45617869', '#456,green avenue,goli mar ke ,bathinda', 'anjana'),
(7, 'abnD@gmail.com', '4567981235', '123sd123', '#123ee46,phulan da baag,bathinda\r\n', 'sanju'),
(8, 'navz', '2314563542', '123456', 'hxxsvcshvhhbzz', 'navneet'),
(9, 'frhth', '9454466566', '123456', 'gulabgarh', 'jassi'),
(10, 'deepak kumar', '8427897988', '8427897988', 'babaf arid nagar', 'deepak kumar'),
(11, 'chirG GOYAL', '9780263650', '9790263650', 'bathinda jhujha rsingh nagar #20094', 'chirag goyal'),
(12, 'vdhfdjsk', '784567999', 'hefjekdbfk', 'xgddhsjdu', 'adggsfkjhk'),
(13, 'sahil', '7814122871', 'samsung', 'bathinda', 'sahil mittal'),
(14, '', '', '', '', ''),
(15, '', '8778', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
