<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	</head>
	<body>
		<div class="main">
		<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div style="margin-top:50px;"class="col-md-offset-4 col-md-4">
			<p class="log text-center">Sign Up<p>
				<form action="dashuserupdash.php" method="post">
					<i class="fa fa-user ufa"></i><input type="text" name="lovjuname" placeholder="name" class="in1" style="margin-bottom:-110px;"><br/>
				<i class="fa fa-user ufa"></i><input type="text" name="lovname" placeholder="Username" class="in1" style="margin-top:20px;"><br/>
				<i class="fa fa-key pfa"></i><input type="password" name="lovpass" placeholder="Password" class="in2"><br/>
				<input type="submit" value="Sign up" name="justlovme" class="btn btn-md btn-lg btn-block" style="margin-top:25px;background-color:#005580;color:#fff;">
				
			</form>
			
		</div>
	</div>
	</body>
</html>