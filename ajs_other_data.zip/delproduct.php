<?php
	
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);


	$prod_id=$_GET['prod_id'];
	$mainid=$_GET['mainid'];
	$tyr="delete from products where id='$prod_id'";
		mysqli_query($con,$tyr);
		//header("location:commondash.php");

		?>
		<script>window.location='commondash.php?id=<?php echo $mainid;?>';</script>
		<?php
?>