<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
if(isset($_POST['justlvme']))
{
$ulvname=$_POST['lvname'];
$ulvpass=$_POST['lvpass'];

$qry1="select id,username,name from admin_login where username='$ulvname' AND password='$ulvpass'";
$data1=mysqli_query($con,$qry1);
						$counter1=mysqli_num_rows($data1);
						
						if($counter1>0)
								{
									$row1=mysqli_fetch_array($data1);
									$_SESSION['uid']=$row1[0];
									
									$_SESSION['name']=$row1[1];
									$_SESSION['hkjk']=$row1[2];
									header("location:dashlogined.php");
								}
	else
	{
		header("location:dashboard.php?id=2000");
		
	}
}
?>