		
<?php
include('connection.php');

	$id = $_GET['$id'];

		$sql="delete from user_message where id =$id";
				$success=mysql_query($sql);
				if($success)
				{
				 	?>
						<script>
							alert('Contact Information deleted Permanently');
        					window.location.href='contactus.php?success';
        				</script>
					<?php
					}
				else
					{
						

						?>
							<script>
									alert('Contact Information cant be deleted');	
        							window.location.href='contactus.php?failed';
        					</script>
						<?php
					
					}

	 	
	?>