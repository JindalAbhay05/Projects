<?php
	$con=mysqli_connect("localhost","root","","matrimonial");
	//mysqli_select_db("matrimonial",$con);
?>