<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
?>
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<script src="css/jquery.min.js"></script>
		
</head>
	<body>
		<div class="main">
			<div style="position:fixed;z-index:10000;width:100%;">
			<?php
			    include('menu2.php');
			?>
			</div>
 			
 			<!---------------------------------------------slider-------------------------------------------->
 		  <div class="clearfix"></div>
 			<div  class="slud">
 				<?php
 					include('slider.php');
 				?>
 			</div>

 			<hr>
 			
 			<div class="clearfix">
 			</div>

 			<div class="col-md-offset-2 border1 col-md-8">
 				<img src="images/ds.jpg" class="img-responsive">
 			</div>
 			
 			<div class="clearfix"></div>

 			<hr>
 			
 			<div class="container">
 				<?php
					$qry="select id,photo from new_category";
				$res=mysqli_query($con,$qry);
				while($row=mysqli_fetch_array($res))
				{
					$_SESSION['main']=$row[0];

				?>
                
 				<div  class="col-md-3 a">
 					
 					<a href="maincat.php?mainid=<?php echo $row[0];?>">
 						<img src="images/<?php echo $row[1];?>" class="img-responsive border1 rad borderr"></a>
 					<a href="maincat.php?mainid=<?php echo $row[0];?>" class="b">Buy Now</a>
 				</div>
 				
 				
 				<?php
					}					 					
 					?>
 		</div>

 		<div class="clearfix"></div>
 		
 		<hr>

 		<div class="container"><!--handpicked global brands-->
 			<div  style="margin-bottom:20px;" class="col-md-11">
 				<a class="Z R" href="#">HANDPICKED</a><br>
 				<span style="color:grey;">The best of global brands,at your doorsteps</span>
 			</div>
 			<div>
 				<?php
 				$cmd="select id,maincat_id,name,photo,descrp_line from companies where maincat_id=16";
 				$res=mysqli_query($con,$cmd);
 				while($row=mysqli_fetch_array($res))
 				{
 				?>
 				<a href="designing.php?brid=<?php echo $row[0];?>&mainid=<?php echo $row[1];?>"><div class="col-md-4">
 					<div class="v"  style="overflow:hidden;">
 						<img src="images/<?php echo $row[3];?>" width="350px" height="197px"class="img-responsive x">
 					</div>
 					<div class="text-center">
 						<span class="Z R"><?php echo $row[2];?></span><br>
 						<span class="abc"style="color:grey;"><?php echo $row[4];?></span>
 					</div>
 				</div></a>
 				<?php
					}
 				
 				$cmd1="select * from companies where id='12'";
 				$res1=mysqli_query($con,$cmd1);
 				while($row1=mysqli_fetch_array($res1))
 				{
 				?>
 				<a href="designing.php?brid=<?php echo $row1[0];?>&mainid=<?php echo $row1[1];?>"><div class="col-md-4" style="overflow:hidden;">
 					<div class="v" style="overflow:hidden;">
 						<img src="images/<?php echo $row1[3];?>" class="img-responsive x">
 					</div>
 					<div class="text-center">
 						<span class="Z R" ><?php echo $row1[2];?></span><br>
 						<span class="abc"style="color:grey;"><?php echo $row1[4];?></span>
 					</div>
 				</div></a>
 				<?php
 				}
 				$cmd2="select * from companies where id='13'";
 				$res2=mysqli_query($con,$cmd2);
 				while($row2=mysqli_fetch_array($res2))
 				{
 				
 				?>
 				<a href="designing.php?brid=<?php echo $row2[0];?>&mainid=<?php echo $row2[1];?>"><div class="col-md-4">
 					<div class="v" style="overflow:hidden;">
 						<img src="images/<?php echo $row2[3];?>" class="img-responsive x" style="overflow:hidden;">
 					</div>
 					<div class="text-center">
 						<span class="Z R" ><?php echo $row2[2];?></span><br>
 						<span class="abc"style="color:grey;"><?php echo $row2[4];?></span>
 					</div>
 		</div></a>
 		<?php 
 		}

 		?>
 	</div>
 	<div  class="clearfix"></div>
 		<div style="margin-top:20px;">
 			<?php
 			$cmd3="select * from companies where id='14'";
 				$res3=mysqli_query($con,$cmd3);
 				while($row3=mysqli_fetch_array($res3))
 				{
 			?>
 				<a href="designing.php?brid=<?php echo $row3[0];?>&mainid=<?php echo $row3[1];?>"><div class="col-md-4">
 					<div class="v" style="overflow:hidden;">
 						<img src="images/<?php echo $row3[3];?>" class="img-responsive x" style="overflow:hidden;">
 					</div>
 					<div class="text-center">
 						<span class="Z R"><?php echo $row3[2];?></span><br>
 						<span class="abc" style="color:grey;"><?php echo $row3[4];?></span>
 					</div>
 				</div></a>
 				<?php
 				}
 				$cmd4="select * from companies where id='23'";
 				$res4=mysqli_query($con,$cmd4);
 				while($row4=mysqli_fetch_array($res4))
 				{
 				?>
 				<a href="designing.php?brid=<?php echo $row4[0];?>&mainid=<?php echo $row4[1];?>"><div class="col-md-4">
 					<div class="v" style="overflow:hidden;">
 						<img src="images/<?php echo $row4[3];?>" width="350" height="197" class="x">
 					</div>
 					<div class="text-center">
 						<span class="Z R"><?php echo $row4[2];?></span><br>
 						<span class="abc" style="color:grey;"><?php echo $row4[4];?></span>
 					</div>
 				</div></a>
 				<?php
 				}
 				$cmd5="select * from companies where id='18'";
 				$res5=mysqli_query($con,$cmd5);
 				while($row5=mysqli_fetch_array($res5))
 				{
 				?>
 				<a href="designing.php?brid=<?php echo $row5[0];?>&mainid=<?php echo $row5[1];?>"><div class="col-md-4">
 					<div class="v" style="overflow:hidden;">
 						<img src="images/<?php echo $row5[3];?>" class="img-responsive x">
 					</div>
 					<div class="text-center">
 						<span class="Z R"><?php echo $row5[2];?></span><br>
 						<span class="abc" style="color:grey;"><?php echo $row5[4];?></span>
 					</div>
 		</div></a>
 		<?php
 		}
 		?>
 	</div>
 </div>
 			<div class="clearfix"></div>

 			<div class="ca col-md-12">
 				<div class="col-md-11 col-md-offset-1"> 
 				<p style="font-size:25px;font-weight:bolder;">ONLY THE BEST</p>
 				<span style="color:#9495a5;">Popular categories that people are shopping for right now</span>
 			</div>
 				<div style="padding:0px 0px;margin-top:30px;padding-left:0px;" class="col-md-5 col-md-offset-1">
 					<div class="col-md-6" style="padding-left:0px;">
 						<img src="images/men_HP.jpg" >
 					
 					</div>
 					<div class="col-md-6">
 							<a href="maincat.php?mainid=<?php echo $_SESSION['main'];?>" style="text-decoration:none;font-size:18px;font-weight:bolder;padding-bottom:0px;padding-right:0px;">Men's</a>
 						<span style="color:#9495a5;">Popular</span>

 						<!--<a href="designing.php?subid=<?php //echo ?>&mainid=<?php //echo "12"?>"style="text-decoration:none;" ><p class="borderb l" style="margin-top:15px;">T-shirts &nbsp;&nbsp;&nbsp;&nbsp;<i style="font-size:20px;" class="fa fa-angle-right"></i></p></a>-->
 						<?php
 						$cmd45="select id,pcatid,subcatname from add_subcat where pcatid=12";
 						$res=mysqli_query($con,$cmd45);
 						while($row=mysqli_fetch_array($res))
 						{
 						?>
 						<a href="designing.php?subid=<?php echo $row[0];?>&mainid=<?php echo $row[1];?>" style="text-decoration:none;"><p class="borderb l"><?php echo $row[2];?>  &nbsp;&nbsp;&nbsp;&nbsp;<i style="font-size:20px;" class="fa fa-angle-right"></i></p></a>
 						<?php
 						}
 						?>
 												
 						
 					</div>
 				</div>
 				<div style=" padding:0px 0px;margin-top:30px;" class="col-md-6">
 					<div class="col-md-6" style="padding-right:0px;">
 						<img src="images/women_HP.jpg" >
 					
 					</div>
 					<div class="col-md-6" style="padding-left:0px;">
 							<a href="maincat.php?mainid=<?php echo $_SESSION['main'];?>"style="text-decoration:none;font-size:18px;font-weight:bolder;padding-bottom:0px;">Women's</a>
 						<span style="color:#9495a5;">Popular</span>
 						<?php
 						$cmd15="select id,pcatid,subcatname from add_subcat where pcatid=7";
 						$res15=mysqli_query($con,$cmd15);
 						while($row15=mysqli_fetch_array($res15))
 						{
 						?>
 						<a href="designing.php?subid=<?php echo $row15[0];?>&mainid=<?php echo $row15[1];?>" style="text-decoration:none;"><p class="borderb l" style=" margin-top:15px;"><?php echo $row15[2]?> &nbsp;&nbsp;&nbsp;&nbsp;<i style="font-size:20px;" class="fa fa-angle-right"></i></p></a>
 						<?php
 						}
 						?>
 						
 												
 					</div>

 				</div>
 			</div>
		</div>
	</body>
</html>
