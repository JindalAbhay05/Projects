		
<?php
include('connection.php');
	

	$id = $_GET['$id'];

		$sql="delete from register where id =$id";
				$success=mysql_query($sql);
				if($success)
				{
				 	?>
						<script>
							alert('Contact Information deleted Permanently');
        					window.location.href='userreg.php?success';
        				</script>
					<?php
					}
				else
					{
						

						?>
							<script>
									alert('Contact Information cant be deleted');	
        							window.location.href='userreg.php?failed';
        					</script>
						<?php
					
					}

	 	
	?>