
					<?php
					$cn=mysqli_connect("localhost","root","","youngsters");
						//mysqli_select_db("youngsters",$cn);

					?>
 
					<div class="container" id="sall">
					<?php 
			if($_GET['subid']!="" && $_GET['mainid']!="")
					{
						$cmde="select id,name from new_category where id=".$_GET['mainid'];
						$rese=mysqli_query($cn,$cmde);
						
						while($rowe=mysqli_fetch_array($rese))
						{
					?>

					<p style="font-weight:bolder;font-size:20px;margin-bottom:-15px;" class="abc"><?php echo $rowe[1];?></a>
					<?php
					}
					?>
					<hr>
					<?php
						$cmd6="select id,newcat_id,name,price,photo from products where subcat_id=".$_GET['subid'];
						$res6=mysqli_query($cn,$cmd6);
						$c=0;
						while($row6=mysqli_fetch_array($res6))
						{
							$c+=1;
							?>
							<a href="buy.php?prod_id=<?php echo $row6[0];?>&mainid=<?php echo $row6[1];?>"><div width="150px" id="nam<?php echo $c?>" class="col-md-3 vicky" style="padding-left:0px;padding-right:0px;">
						<center><img src="images/products/<?php echo $row6[4];?>" width="190px" height="238"></center>
					
						<div class="as" style="margin-top:5px;">
							<center><a class="q abc">BUY NOW</a>
								<a class="q1 abc">QUICK VIEWS</a></center>
						</div>
						<center><p class="r" type="margin-bottom:0px;font-weight:bolder;"><?php echo $row6[2];?></p>	
						<p class="rs" style="margin-top:0px;font-weight:bolder;margin-top:3px;">Rs<?php echo $row6[3];?></p></center>
						<div class="siz">
							
							<a style="margin-left:100px;text-decoration:none;" class="abc">S</a>
							<a style="text-decoration:none;" class="abc">M</a>
							<a style="text-decoration:none;" class="abc">L</a>
							<a style="text-decoration:none;" class="abc">XL</a>
							<a style="text-decoration:none;" class="abc">XXl</a>
						
						</div>
					</div></a>
					<?php
						}
						}
			elseif($_GET['sprid']!="" && $_GET['mainid']!="")
						{
							//echo $_GET['sprid'];
						$cmde="select id,name from new_category where id='".$_GET['mainid']."'";
						$rese=mysqli_query($cn,$cmde);
						while($rowe=mysqli_fetch_array($rese))
						{   
					?>

					<p style="font-weight:bolder;font-size:20px;" class="abc"><?php echo $rowe[1];?></a>
					<?php
					}
					?>
					<hr>
					<?php
					//echo $_GET['sprid'];
						$cmd1="select id,name,price,photo,newcat_id from products where sprcat_id=".$_GET['sprid'];
						$res1=mysqli_query($cn,$cmd1);
						$c=0;
						while($row1=mysqli_fetch_array($res1))
						{
							$c+=1;
						?>
						<a href="buy.php?prod_id=<?php echo $row1[0];?>&mainid=<?php echo $row1[4];?>">
						
						
						<div id="nam<?php echo $c; ?>" class="col-md-3 vicky" style="padding-left:0px;padding-right:0px;">
						<center><img src="images/products/<?php echo $row1[3];?>" width="190px" height="238"></center>
					
						<div class="as" style="margin-top:5px;">
							<center><a class="q abc">BUY NOW</a>
								<a class="q1 abc">QUICK VIEWS</a></center>
						</div>
						<center><p class="r" type="margin-bottom:0px;font-weight:bolder;"><?php echo $row1[1];?></p>
						<p class="rs" style="margin-top:0px;font-weight:bolder;margin-top:3px;">Rs<?php echo $row1[2];?></p></center>
						<div class="siz">
							
							<a style="margin-left:100px;text-decoration:none;"class="abc">S</a>
							<a style="text-decoration:none;" class="abc">M</a>
							<a style="text-decoration:none;" class="abc">L</a>
							<a style="text-decoration:none;" class="abc">XL</a>
							<a style="text-decoration:none;" class="abc">XXl</a>
						
						</div>
					</div>
					
					</a>
					<?php
					}
							
						
					}
			else
					{

						$cmde="select id,name from new_category where id=".$_GET['mainid'];
						$rese=mysqli_query($cn,$cmde);
						while($rowe=mysqli_fetch_array($rese))
						{   
					?>

					<p style="font-weight:bolder;font-size:20px;" class="abc"><?php echo $rowe[1];?></p>
					<?php
					}

					?>
					<hr>
					<?php
					//echo $_GET['brid'];
					$ght="select id,name from companies where id='".$_GET['brid']."'";
					$tyh=mysqli_query($cn,$ght);
					while($uyt=mysqli_fetch_array($tyh)) 
					{
						$kjh=$uyt[1];
						//echo $kjh;	
					}
					$cmd10="select id,newcat_id,name,price,brand,description,photo from products where brand='".$kjh."'";
						$res10=mysqli_query($cn,$cmd10);
						$c=0;
						while($row10=mysqli_fetch_array($res10))
						{
								$c+=1;
					?>
					
								<?php
								
								?>		
							<a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>"><div width="150px" id="nam<?php echo $c;?>" class="col-md-3 vicky" style="padding-left:0px;padding-right:0px;">
						<center><img src="images/products/<?php echo $row10[6];?>" width="190px" height="238"></center>
					
						<div class="as" style="margin-top:5px;">
							<center><a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>"class="q">BUY NOW</a>
								<a href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>" class="q1">QUICK VIEWS</a></center>
						</div>
						<center><p class="r" type="margin-bottom:0px;font-weight:bolder;"><?php echo $row10[2];?></p>
						<p class="rs" style="margin-top:0px;font-weight:bolder;margin-top:3px;">Rs <?php echo $row10[3];?></p></center>
						<div class="siz">
							
							<a style="margin-left:100px;text-decoration:none;"href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">S</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">M</a>
							<a style="text-decoration:none;"href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">L</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">XL</a>
							<a style="text-decoration:none;" href="buy.php?prod_id=<?php echo $row10[0];?>&mainid=<?php echo $row10[1];?>">XXl</a>
						
						</div>
					</div></a>
					<?php
					$c++;
						}
					}
					?>
				</div>
					
						
						
					
				
		<script>
		$(document).ready(function(){
			$(".as").hide();
			$(".siz").hide();

			var id;
			$(".vicky").hover(function(){

				 id=this.id;

						$("#"+id+" .r").hide();
						$("#"+id+" .as").show();
						$("#"+id+" .siz").show();
						
				});

					$(".vicky").mouseleave(function(){
						
						$("#"+id+" .r").show();
						$("#"+id+" .as").hide();
						$("#"+id+" .siz").hide();

					});
		});
		</script>		