<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="../../ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script src="../../maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<script src="css/jquery.min.js"></script>
		<script>
		$(document).ready(function(){
		$("#sh").hide();
		$("#sh1").hide();
		$("#shall").hide();
		$("#add").click(function(){
			$("#sh").slideToggle();
		});
		$("#sub").click(function(){
			$("#sh1").slideToggle();
		});
		$("#arc").click(function(){
			$("#shall").slideToggle();
		});
	});
		</script>
	</head>
	<body>
		<div class="main">
				<div><!--menu-->
						<?php
			   				 include('menu2.php');
						?>
				</div><!--menu endss-->
		
			
			<div>
			<div class="col-md-4">
				<center><a class="abc" id="add"><i class="fa fa-plus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Add photo.</span>
					

				</a></center>
			</div>
			<div class="col-md-4">
				<center><a class="abc" id="sub"><i class="fa fa-minus" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">Delete Photo.</span>
					

				</a></center>
			</div>
			<div class="col-md-4">
				<center><a class="abc" id="arc"><i class="fa fa-archive" style="font-size:30px;"></i>
					<br><span style="color:black;font-weight:bolder;">All images.</span>
					

				</a></center>
			</div>
		</div>
		<div class="clearfix"></div>
		<hr>
		<hr>
			<div id="sh"class="col-md-4 col-md-offset-4 slider">
				<form action="dashslider.php" method="post" enctype="multipart/form-data"> 
					<label>1.Name:</label><input style="margin-left:80px;margin-top:10px;" type="text" name="name"><br>
					<label style="margin-top:20px">2.Add Photo:</label>
					<input style="margin-left:80px;" type="file" name="slider"> 
					<label>3.Link:</label> <input style="margin-left:0px;" type="text" name="link"><br>
					<input type="submit" value="Submit" name="subkl" style="margin-bottom:50px;margin-top:15px;"
					 class="btn btn-md btn-primary btn-block"> 
				</form>
			</div>
			<?php
			if(isset($_POST['subkl']))
			{
				$name=$_POST['name'];
				$link=$_POST['link'];
				$photo=basename($_FILES['slider']['name']);
				$cmd="insert into slider_photos(photo,name,link) value('$photo','$name','$link')";
				mysqli_query($cmd);
				move_uploaded_file($_FILES['slider']['tmp_name'],"images/".$photo);
				
			}
			?>
			<div id="sh1">
				<div style="overflow:scroll;background-color:;">
				<?php		
				$scr="select id,photo,name from slider_photos";
				$res=mysqli_query($con,$scr);
				while($row=mysqli_fetch_array($res))
				{
					
					
					
					?>
						
						<div class="col-md-4">
							<img src="images/<?php echo $row[1];?>" width="250px">
						</div>
						<div class="col-md-4">
							<p><?php echo $row[2];?></p>
						</div>
						<div class="col-md-4">
							<a class="btn abc" href="delsliderphoto.php?slider_id=<?php echo $row[0]; ?>" style="background-color:#000;color:#fff;padding:10px 10px;margin-top:10px;">Delete</a>
							</div>
					<div class="clearfix"></div>
					<?php
				}

				
				
				?>
			</div>
			</div>
				<div id="shall" style="overflow:scroll;">
				<?php
				$scr="select id,photo,name from slider_photos";
				$res=mysqli_query($con,$scr);
				while($row=mysqli_fetch_array($res))
				{
					$id =$row[0];
					
					$_SESSION['del']=$id;
					?>
						
						<div class="col-md-4">
							<img src="images/<?php echo $row[1];?>" width="250px">
						</div>
						<div class="col-md-8">
							<p><?php echo $row[2];?></p>
						</div>
					<div class="clearfix"></div>
					<?php
				}
				?>
			</div>
	</div>
	</body>
</html>