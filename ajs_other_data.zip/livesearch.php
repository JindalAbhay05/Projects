<?php
$cn=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$cn);

 $q=$_GET["q"];
      $cmd="select id,name,newcat_id from products"; 
      $res=mysqli_query($cn,$cmd);

      while($row=mysqli_fetch_array($res))
      {
           if(stristr($row['name'],$q))  
          {
          echo "<a href='buy.php?pid=".$row['id']."&mainid=".$row['newcat_id']."'>".$row['name']."</a><br>"; 
          }
      }
      ?>
 
 