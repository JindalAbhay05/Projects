<?php 

//$db = new PDO('mysql:host=localhost:3306;dbname=patialaa_pupa','patialaa_abhay','abhay jindal');
$db = new PDO('mysql:host=localhost;dbname=pupa','root','');
?>