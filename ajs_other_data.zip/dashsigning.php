<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<script>
	$(document).ready(function(){
			$("#srec").hide();				
			$("#rec").click(function(){
					$("#srec").slideToggle();				
			});
	});
	</script>
	</head>
	<body>
		<div class="main">
			<div>
			<?php
				include('menu2.php');
			?>
		</div>
		<div>
			<center><a class="abc" id="rec" ><i class="fa fa-archive" style="font-size:30px;margin-top:10px;"></i>
					<br><span style="color:black;font-weight:bolder;">Watch for Record.</span>
					

				</a></center>
		</div>
		<hr>
		<hr>
		<div id="srec">
			<?php
			$con=mysqli_connect("localhost","root","","youngsters");
   			//mysqli_select_db("youngsters",$con);
			$tasfjk="select username,address,name,phone_numbr from user_login"; 
			$usdj=mysqli_query($con,$tasfjk);?>
			<table class="table" border='1'>
			<tr class="thead">
			<th>Username</th>
			<th>Name</th>
			<th>Phone Number</th>
			<th>Address</th>
						</tr>
			<?php
			while($osnj=mysqli_fetch_array($usdj))
			{
				?>
			<tr>
			<td><?php echo $osnj[0]; ?></td>
			<td><?php echo $osnj[2]; ?></td>
			<td><?php echo $osnj[3]; ?></td>
			<td><?php echo $osnj[1]; ?></td>
		
			</tr>
			<?php
			}
			?>
			</table>
		</div>

		</div>
	</body>
</html>
