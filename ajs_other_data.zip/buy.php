<?php
$con=mysqli_connect("localhost","root","","youngsters");
//mysqli_select_db("youngsters",$con);
session_start();
if(isset($_GET['prod_id'])&&isset($_GET['mainid']))
{
	
$_SESSION['prod_id']=$_GET['prod_id'];
$_SESSION['mainid']=$_GET['mainid'];


}
?>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<script src="css/jquery.min.js"></script>

  <!--addclassjqueery--><script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<script>
	$(document).ready(function(){
		$("#mige1").hide();
		$("#mige2").hide();
		$("#mige3").hide();
		
		$("#bgn1").hide();
		$("#mig").mouseover(function(){
			$("#mige1").hide();
			$("#mige").show();
			$("#mige1").hide();
			$("#mige1").hide();
		});
		
	$("#mig1").mouseover(function(){
		$("#mige").hide();
		$("#mige2").hide();
		$("#mige3").hide();
		$("#mige1").show();
	});
	
	$("#mig2").mouseover(function(){
		$("#mige").hide();
		$("#mige2").show();
		$("#mige3").hide();
		$("#mige1").hide();
	});
	
	$("#mig3").mouseover(function(){
		$("#mige").hide();
		$("#mige2").hide();
		$("#mige3").show();
		$("#mige1").hide();
	});
	
		$("#size1").click(function(){
			$("#bgn1").addClass("hgf");
		});
		$("#size1").click(function(){
			$("#size1").addClass("siez");
		});
		$("#size2").click(function(){
			$("#size2").addClass("siez");
		});
		$("#size3").click(function(){
			$("#size3").addClass("siez");
		});
		$("#size4").click(function(){
			$("#size4").addClass("siez");
		});
		$("#size5").click(function(){
			$("#size5").addClass("siez");
		});
		$("#bgn").mouseover(function(){
			$("#bgn1").show();
			$("#bgn2").hide();
		});
		$("#bgn").mouseleave(function(){
			$("#bgn1").hide();
			$("#bgn2").show();
		});
	});
	</script>
</head>
<body>
	<div class="main">
	<div>
		<?php
		include('menu2.php');
			?>
	</div>
	<div class="col-md-4" style="margin-top:30px;padding-right:0px;">

		<div class="col-md-2" style="padding-right:0px;">
			<?php 
		$cmd100="select id,newcat_id,photo,photo1,photo2,photo3 from products where id='".$_SESSION['prod_id']."'";
						$res100=mysqli_query($con,$cmd100);
						while($row100=mysqli_fetch_array($res100))
						{
							
							?>
			<img src="images/products/<?php echo $row100[2];?>" id="mig" class="img" width="48px" style="margin-bottom:9px;" ><br>
			<img src="images/products/<?php echo $row100[3];?>" id="mig1" class="img" width="48px" style="margin-bottom:9px;" ><br>
			<img src="images/products/<?php echo $row100[4];?>" id="mig2" class="img" width="48px" style="margin-bottom:9px;" ><br>
			<img src="images/products/<?php echo $row100[5];?>" id="mig3" class="img" width="48px" style="margin-bottom:9px;" >
		<?php
	}?>
		
		</div>
		
		<div class="col-md-10" style="padding-left:0px;">
			<?php //echo $_SESSION['prod_id'];
		$cmd200="select id,newcat_id,photo,photo1,photo2,photo3 from products where id='".$_SESSION['prod_id']."'";
						$res200=mysqli_query($con,$cmd100);
						while($row200=mysqli_fetch_array($res200))
						{
							
							?>
			<img id="mige" src="images/products/<?php echo $row200[2];?>" width="350px" >
			<img id="mige1" src="images/products/<?php echo $row200[3];?>" width="350px" >
			<img id="mige2" src="images/products/<?php echo $row200[4];?>" width="350px" >
			<img id="mige3" src="images/products/<?php echo $row200[5];?>" width="350px" >
			<?php
		}?>
		</div>
	</div>
	<div class="col-md-8" style="margin-top:30px;">
		<?php
		$cmd97="select id,newcat_id,name,price,description,model,towearwith,material from products where id='$_SESSION[prod_id]'";
						$res97=mysqli_query($con,$cmd97);
						while($row97=mysqli_fetch_array($res97))
						
							{
							?>
			<p style="font-size:20px;"><?php echo $row97[2];?></p>
			<p style="font-weight:bold;font-size:18px;">Rs <?php echo $row97[3];?></p>
			<hr>	
			<div>
				<p style="color:#F08080;font-weight:bolder;font-size:15px;" id="bgn1"><i>PLEASE SELECT SIZE:</i></p>
			<p style="font-size:16px;font-weight:bolder;color:#0b0b0b;" id="bgn2"><i>SELECT A SIZE:</i></p>
			
			<!--<div class="col-md-1 col-mf-offset-2" style="padding:0px;">
				<span class="abc" id="size1 six1" active name="oiu1"style="display:block;border-radius:10px 10px;font-size:18px;"><center>S</center></span>
			</div>
			<div class="col-md-1" style="padding:0px;">
				<span class="abc" id="size2 six2" name="oiu2" style="display:block;font-wright:bolder;border-radius:10px 10px;font-size:18px;"><center>M</center></span>
			</div>
			<div class="col-md-1" style="padding:0px;">
				<span class="abc" id="size3 six3" name="oiu3"style="display:block;font-wright:bolder;border-radius:10px 10px;font-size:18px;"><center>L</center></span>
			</div>
			<div class="col-md-1" style="padding:0px;">
				<span class="abc" id="size4 six4"name="oiu4" style="display:block;font-wright:bolder;border-radius:10px 10px;font-size:18px;"><center>XL</center></span>
			</div>
			<div class="col-md-1" style="padding:0px;">
				<span class="abc" id="size5 six5" name="oiu5" style="display:block;font-wright:bolder;border-radius:10px 10px;font-size:18px;"><center>XXL</center></span>	
			</div>-->
			<form action="buynow.php?prod_id=<?php echo $_GET['prod_id'];?>&mainid=<?php echo $_GET['mainid'];?>" method="post">
			<select name="seld"><option value="0">S</option><option value="1">M</option><option value="2">L</option><option value="3">XL</option><option value="4">XLL</option></select>
		</div><br>
		<br>
		<input type="submit" value="BUY NOW" name="nji" style="display:block;width:250px;border-radius:5px 5px;" class="btn btn-lg btn-primary" >
	</form>
			<p style="margin-top:20px;"><?php echo $row97[5];?></p>
			<hr>
			<p><?php echo $row97[6];?></p>
			<p style="margin-top:20px;"><span style="font-weight:bolder;color;#0b0b0b;">Product Details</span><br><?php echo $row97[4];?></p>
			<p><span style="margin-top:20px;color:#0b0b0b;font-weight:bolder;">Material & Care</span><br><?php echo $row97[7];?></p>
			<?php
		}
		


?>
	</div>
	<!--<div class="col-md-2" style="dispay:block;width:200px;">
		<center><p style="margin-top:10px;">SIMILAR</p></center>
		<hr>
		<div style="border:1px solid #a9a9a9;">
			<div style="margin-top:15px;">
				<center><img src="images/products/Harpa-Women-Tops_1.jpg" width="120px"></center>
			</div>
			<div>
				<center><p style="margin-bottom:0px;margin-top:5px;">name</p><p>Price:Rs</p></center>
			</div>
		</div>-->
	</div>
</body>
</html>
